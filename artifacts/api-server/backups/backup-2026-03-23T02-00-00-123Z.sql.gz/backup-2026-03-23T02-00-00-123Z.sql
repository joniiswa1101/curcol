--
-- PostgreSQL database dump
--

\restrict Nanbqbq2aDMTVfwQbCmdMSKiSpLsG3Sk9kw0pZOY46f6c8edE2FW87x9Vwvpbby

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: canvas_element_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.canvas_element_type AS ENUM (
    'freehand',
    'rectangle',
    'ellipse',
    'line',
    'arrow',
    'text',
    'sticky_note',
    'image'
);


ALTER TYPE public.canvas_element_type OWNER TO postgres;

--
-- Name: cico_check_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.cico_check_type AS ENUM (
    'office',
    'wfh'
);


ALTER TYPE public.cico_check_type OWNER TO postgres;

--
-- Name: cico_presence_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.cico_presence_status AS ENUM (
    'present',
    'break',
    'wfh',
    'absent',
    'off'
);


ALTER TYPE public.cico_presence_status OWNER TO postgres;

--
-- Name: conversation_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.conversation_type AS ENUM (
    'direct',
    'group',
    'announcement',
    'whatsapp'
);


ALTER TYPE public.conversation_type OWNER TO postgres;

--
-- Name: member_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.member_role AS ENUM (
    'admin',
    'member'
);


ALTER TYPE public.member_role OWNER TO postgres;

--
-- Name: message_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.message_type AS ENUM (
    'text',
    'image',
    'file',
    'system'
);


ALTER TYPE public.message_type OWNER TO postgres;

--
-- Name: task_priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.task_priority AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);


ALTER TYPE public.task_priority OWNER TO postgres;

--
-- Name: task_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.task_status AS ENUM (
    'todo',
    'in_progress',
    'review',
    'done',
    'cancelled'
);


ALTER TYPE public.task_status OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'admin',
    'manager',
    'employee'
);


ALTER TYPE public.user_role OWNER TO postgres;

--
-- Name: wa_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.wa_status AS ENUM (
    'unassigned',
    'assigned',
    'resolved'
);


ALTER TYPE public.wa_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    author_id integer NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.announcements_id_seq OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachments (
    id integer NOT NULL,
    message_id integer,
    file_name text NOT NULL,
    file_size integer NOT NULL,
    mime_type text NOT NULL,
    url text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attachments OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id integer,
    details jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: canvas_board_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.canvas_board_members (
    id integer NOT NULL,
    board_id integer NOT NULL,
    user_id integer NOT NULL,
    role character varying(20) DEFAULT 'viewer'::character varying NOT NULL,
    added_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.canvas_board_members OWNER TO postgres;

--
-- Name: canvas_board_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.canvas_board_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.canvas_board_members_id_seq OWNER TO postgres;

--
-- Name: canvas_board_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.canvas_board_members_id_seq OWNED BY public.canvas_board_members.id;


--
-- Name: canvas_boards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.canvas_boards (
    id integer NOT NULL,
    name text NOT NULL,
    conversation_id integer,
    created_by_id integer NOT NULL,
    thumbnail text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_public boolean DEFAULT true NOT NULL
);


ALTER TABLE public.canvas_boards OWNER TO postgres;

--
-- Name: canvas_boards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.canvas_boards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.canvas_boards_id_seq OWNER TO postgres;

--
-- Name: canvas_boards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.canvas_boards_id_seq OWNED BY public.canvas_boards.id;


--
-- Name: canvas_elements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.canvas_elements (
    id integer NOT NULL,
    board_id integer NOT NULL,
    element_type public.canvas_element_type NOT NULL,
    x real DEFAULT 0 NOT NULL,
    y real DEFAULT 0 NOT NULL,
    width real DEFAULT 0,
    height real DEFAULT 0,
    rotation real DEFAULT 0,
    points jsonb,
    content text,
    style jsonb DEFAULT '{}'::jsonb NOT NULL,
    z_index integer DEFAULT 0 NOT NULL,
    created_by_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.canvas_elements OWNER TO postgres;

--
-- Name: canvas_elements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.canvas_elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.canvas_elements_id_seq OWNER TO postgres;

--
-- Name: canvas_elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.canvas_elements_id_seq OWNED BY public.canvas_elements.id;


--
-- Name: cico_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cico_logs (
    id integer NOT NULL,
    employee_id text NOT NULL,
    action text NOT NULL,
    location text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    type public.cico_check_type
);


ALTER TABLE public.cico_logs OWNER TO postgres;

--
-- Name: cico_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cico_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cico_logs_id_seq OWNER TO postgres;

--
-- Name: cico_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cico_logs_id_seq OWNED BY public.cico_logs.id;


--
-- Name: cico_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cico_status (
    id integer NOT NULL,
    employee_id text NOT NULL,
    status public.cico_presence_status DEFAULT 'absent'::public.cico_presence_status NOT NULL,
    check_in_time timestamp without time zone,
    check_out_time timestamp without time zone,
    location text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cico_status OWNER TO postgres;

--
-- Name: cico_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cico_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cico_status_id_seq OWNER TO postgres;

--
-- Name: cico_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cico_status_id_seq OWNED BY public.cico_status.id;


--
-- Name: compliance_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_flags (
    id integer NOT NULL,
    message_id integer,
    conversation_id integer,
    user_id integer,
    flag_type text DEFAULT 'pii_detected'::text NOT NULL,
    pii_types jsonb,
    original_content text,
    redacted_content text,
    severity text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by_id integer,
    reviewed_at timestamp without time zone,
    review_note text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_flags OWNER TO postgres;

--
-- Name: compliance_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compliance_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_flags_id_seq OWNER TO postgres;

--
-- Name: compliance_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compliance_flags_id_seq OWNED BY public.compliance_flags.id;


--
-- Name: conversation_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversation_members (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    user_id integer NOT NULL,
    role public.member_role DEFAULT 'member'::public.member_role NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    is_muted boolean DEFAULT false NOT NULL,
    last_read_at timestamp without time zone,
    joined_at timestamp without time zone DEFAULT now() NOT NULL,
    cleared_at timestamp without time zone
);


ALTER TABLE public.conversation_members OWNER TO postgres;

--
-- Name: conversation_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversation_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conversation_members_id_seq OWNER TO postgres;

--
-- Name: conversation_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversation_members_id_seq OWNED BY public.conversation_members.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    type public.conversation_type NOT NULL,
    name text,
    description text,
    avatar_url text,
    created_by_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    whatsapp_contact_phone text,
    whatsapp_contact_name text,
    wa_status public.wa_status DEFAULT 'unassigned'::public.wa_status,
    assigned_to_id integer
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conversations_id_seq OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_attempts (
    id integer NOT NULL,
    user_id integer,
    ip_address text NOT NULL,
    success boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.login_attempts OWNER TO postgres;

--
-- Name: login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_attempts_id_seq OWNER TO postgres;

--
-- Name: login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_attempts_id_seq OWNED BY public.login_attempts.id;


--
-- Name: message_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_favorites (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.message_favorites OWNER TO postgres;

--
-- Name: message_favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.message_favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.message_favorites_id_seq OWNER TO postgres;

--
-- Name: message_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.message_favorites_id_seq OWNED BY public.message_favorites.id;


--
-- Name: message_reactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_reactions (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    emoji text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.message_reactions OWNER TO postgres;

--
-- Name: message_reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.message_reactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.message_reactions_id_seq OWNER TO postgres;

--
-- Name: message_reactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.message_reactions_id_seq OWNED BY public.message_reactions.id;


--
-- Name: message_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_reads (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    read_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.message_reads OWNER TO postgres;

--
-- Name: message_reads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.message_reads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.message_reads_id_seq OWNER TO postgres;

--
-- Name: message_reads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.message_reads_id_seq OWNED BY public.message_reads.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    content text,
    type public.message_type DEFAULT 'text'::public.message_type NOT NULL,
    reply_to_id integer,
    is_pinned boolean DEFAULT false NOT NULL,
    is_edited boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone,
    edited_at timestamp without time zone,
    original_content text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    wa_message_id text,
    is_from_whatsapp boolean DEFAULT false NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: offline_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offline_queue (
    id character varying(255) NOT NULL,
    user_id integer NOT NULL,
    conversation_id integer NOT NULL,
    content text,
    type text DEFAULT 'text'::text NOT NULL,
    attachment_ids jsonb,
    reply_to_id integer,
    status text DEFAULT 'pending'::text NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    error text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    synced_at timestamp without time zone
);


ALTER TABLE public.offline_queue OWNER TO postgres;

--
-- Name: push_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.push_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    platform text DEFAULT 'expo'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_tokens OWNER TO postgres;

--
-- Name: push_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.push_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_tokens_id_seq OWNER TO postgres;

--
-- Name: push_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.push_tokens_id_seq OWNED BY public.push_tokens.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    refresh_token text,
    refresh_expires_at timestamp without time zone
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_comments OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_comments_id_seq OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: task_labels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_labels (
    id integer NOT NULL,
    task_id integer NOT NULL,
    label text NOT NULL
);


ALTER TABLE public.task_labels OWNER TO postgres;

--
-- Name: task_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_labels_id_seq OWNER TO postgres;

--
-- Name: task_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_labels_id_seq OWNED BY public.task_labels.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    status public.task_status DEFAULT 'todo'::public.task_status NOT NULL,
    priority public.task_priority DEFAULT 'medium'::public.task_priority NOT NULL,
    creator_id integer NOT NULL,
    assignee_id integer,
    conversation_id integer,
    due_date timestamp without time zone,
    completed_at timestamp without time zone,
    is_archived boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: user_presence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_presence (
    id integer NOT NULL,
    user_id integer NOT NULL,
    status text DEFAULT 'offline'::text NOT NULL,
    last_seen_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_presence OWNER TO postgres;

--
-- Name: user_presence_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_presence_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_presence_id_seq OWNER TO postgres;

--
-- Name: user_presence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_presence_id_seq OWNED BY public.user_presence.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    employee_id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    phone text,
    department text,
    "position" text,
    avatar_url text,
    role public.user_role DEFAULT 'employee'::public.user_role NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    whatsapp_number text,
    two_factor_secret text,
    two_factor_enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: canvas_board_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_board_members ALTER COLUMN id SET DEFAULT nextval('public.canvas_board_members_id_seq'::regclass);


--
-- Name: canvas_boards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_boards ALTER COLUMN id SET DEFAULT nextval('public.canvas_boards_id_seq'::regclass);


--
-- Name: canvas_elements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_elements ALTER COLUMN id SET DEFAULT nextval('public.canvas_elements_id_seq'::regclass);


--
-- Name: cico_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cico_logs ALTER COLUMN id SET DEFAULT nextval('public.cico_logs_id_seq'::regclass);


--
-- Name: cico_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cico_status ALTER COLUMN id SET DEFAULT nextval('public.cico_status_id_seq'::regclass);


--
-- Name: compliance_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_flags ALTER COLUMN id SET DEFAULT nextval('public.compliance_flags_id_seq'::regclass);


--
-- Name: conversation_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_members ALTER COLUMN id SET DEFAULT nextval('public.conversation_members_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: login_attempts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN id SET DEFAULT nextval('public.login_attempts_id_seq'::regclass);


--
-- Name: message_favorites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_favorites ALTER COLUMN id SET DEFAULT nextval('public.message_favorites_id_seq'::regclass);


--
-- Name: message_reactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reactions ALTER COLUMN id SET DEFAULT nextval('public.message_reactions_id_seq'::regclass);


--
-- Name: message_reads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reads ALTER COLUMN id SET DEFAULT nextval('public.message_reads_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: push_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_tokens ALTER COLUMN id SET DEFAULT nextval('public.push_tokens_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: task_labels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_labels ALTER COLUMN id SET DEFAULT nextval('public.task_labels_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: user_presence id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_presence ALTER COLUMN id SET DEFAULT nextval('public.user_presence_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, title, content, author_id, is_pinned, created_at, updated_at) FROM stdin;
1	Selamat Datang di CorpChat!	Dengan bangga kami memperkenalkan CorpChat - platform komunikasi resmi karyawan yang terintegrasi dengan sistem CICO. Semua percakapan tercatat dan dapat diaudit sesuai kebijakan perusahaan.	2	t	2026-03-16 05:54:18.32617	2026-03-16 05:54:18.28
2	Kebijakan Penggunaan Platform	Harap diperhatikan bahwa semua percakapan di CorpChat bersifat resmi dan dapat diaudit. Gunakan platform ini untuk keperluan pekerjaan. Dilarang menyebarkan informasi rahasia perusahaan kepada pihak yang tidak berwenang.	2	f	2026-03-16 05:54:18.32617	2026-03-16 05:54:18.28
3	Meeting Town Hall Q1 2026	Town Hall meeting akan dilaksanakan pada Jumat, 20 Maret 2026 pukul 14:00 WIB melalui CorpChat Group 'All Hands'. Mohon kehadiran seluruh karyawan.	6	f	2026-03-16 05:54:18.32617	2026-03-16 05:54:18.28
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachments (id, message_id, file_name, file_size, mime_type, url, created_at) FROM stdin;
1	31	Draft PKWT 29122025.docx	45363	application/vnd.openxmlformats-officedocument.wordprocessingml.document	/api/files/1773914339611-861359609.docx	2026-03-19 09:58:59.861
2	\N	test.png	311	image/png	/api/files/1773924134517-555532361.png	2026-03-19 12:42:14.518
3	\N	test-valid.jpg	10	image/jpeg	/api/files/1773941092694-842297746.jpg	2026-03-19 17:24:52.696
4	\N	test-safe.svg	101	image/svg+xml	/api/files/1773941092888-89405093.svg	2026-03-19 17:24:52.889
5	\N	test.txt	10	text/plain	/api/files/1773992249526-670051409.txt	2026-03-20 07:37:29.528
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, action, entity_type, entity_id, details, ip_address, user_agent, created_at) FROM stdin;
1	1	login	session	\N	{"source": "seed"}	\N	\N	2026-03-16 05:10:58.18
2	2	login	session	\N	{"source": "seed"}	\N	\N	2026-03-16 05:01:40.894
3	3	login	session	\N	{"source": "seed"}	\N	\N	2026-03-16 05:25:00.043
4	4	login	session	\N	{"source": "seed"}	\N	\N	2026-03-16 05:45:57.466
5	5	login	session	\N	{"source": "seed"}	\N	\N	2026-03-16 05:15:33.896
6	6	login	session	\N	{"source": "seed"}	\N	\N	2026-03-16 05:14:51.474
7	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 06:10:01.48444
8	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 06:10:12.037076
9	1	login_failed	session	\N	\N	::1	curl/8.14.1	2026-03-16 06:10:18.435457
10	1	login_failed	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-16 07:43:05.545482
11	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 07:44:44.607294
12	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 07:44:59.79541
13	1	login	session	\N	\N	::ffff:127.0.0.1	curl/8.14.1	2026-03-16 07:47:09.887423
14	4	login_failed	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-16 07:47:38.65862
15	4	login	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-16 07:47:41.92753
16	4	send_message	message	11	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-16 07:48:08.980088
17	4	create_conversation	conversation	4	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-16 07:49:44.519465
18	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 09:37:02.123715
19	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 09:37:09.261579
20	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 09:39:37.029757
21	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 09:39:38.656389
22	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 09:39:45.283504
23	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 09:42:01.99404
24	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:24:13.528023
25	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:24:20.98406
26	1	update_user	user	1	\N	::1	curl/8.14.1	2026-03-16 15:24:21.032971
27	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:24:29.120787
28	1	update_user	user	1	\N	::1	curl/8.14.1	2026-03-16 15:24:29.206311
29	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:34:20.174058
30	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:34:28.686061
31	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:34:37.391787
32	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 15:49:47.811577
33	1	cico_checkout	cico	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 15:50:55.492291
34	1	cico_checkout	cico	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 15:51:53.53156
35	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:56:17.380506
36	1	create_user	user	7	\N	::1	curl/8.14.1	2026-03-16 15:56:17.50136
37	7	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 15:56:22.747265
38	7	login_failed	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 15:59:44.343587
39	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-16 15:59:55.464664
40	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-16 16:05:13.602211
41	1	bulk_import_users	user	\N	\N	::1	curl/8.14.1	2026-03-16 16:05:13.773864
42	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-17 17:15:42.313446
43	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-17 17:19:29.405214
44	\N	login_failed_cico	session	\N	{"error": "fetch failed"}	::1	curl/8.14.1	2026-03-17 17:36:34.598873
45	\N	login_failed_cico	session	\N	{"error": "fetch failed"}	::1	curl/8.14.1	2026-03-17 17:36:56.917345
46	\N	login_failed_cico	session	\N	{"error": "CICO connection failed: fetch failed"}	::1	curl/8.14.1	2026-03-17 17:44:39.504424
47	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-17 17:45:19.677504
48	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-17 17:48:05.054193
49	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-17 17:49:38.194646
50	\N	login_failed_cico	session	\N	{"error": "CICO connection failed: fetch failed"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-17 23:51:33.136839
51	\N	login_failed_cico	session	\N	{"error": "CICO connection failed: fetch failed"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-17 23:51:52.900243
52	\N	login_failed_cico	session	\N	{"error": "CICO connection failed: fetch failed"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-17 23:51:56.907883
53	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-17 23:52:28.406287
83	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-18 00:03:36.375535
84	\N	login_failed_cico	session	\N	{"error": "fetch failed"}	::1	curl/8.14.1	2026-03-18 00:03:36.704153
85	\N	login_failed_cico	session	\N	{"error": "fetch failed"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-18 00:08:38.684185
86	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-18 00:08:53.006926
118	\N	login_failed_cico	session	\N	{"error": "Unexpected end of JSON input"}	::1	curl/8.14.1	2026-03-18 00:30:07.069761
119	\N	login_failed_cico	session	\N	{"error": "Unexpected end of JSON input"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-18 00:32:21.077652
120	\N	login_failed_cico	session	\N	{"error": "Invalid credentials"}	::1	curl/8.14.1	2026-03-18 00:40:24.668579
121	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-18 00:42:29.559757
122	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-18 05:34:07.718278
123	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-18 05:41:12.394169
124	7	cico_checkin	cico	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-18 05:41:56.85185
125	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-18 05:50:04.941162
126	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-18 05:50:10.043596
127	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-18 05:52:20.213278
128	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-18 06:15:52.058578
129	\N	login_failed_cico	session	\N	{"error": "Invalid credentials"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-18 06:18:13.54419
130	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-18 06:18:23.260303
131	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-18 12:48:34.31643
132	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-18 13:47:55.881057
133	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-18 16:37:25.278861
134	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 01:08:19.805517
135	1	send_message	message	12	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 08:46:03.671734
136	1	send_message	message	13	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 08:48:04.734838
137	1	send_message	message	14	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 08:48:11.802681
138	1	send_message	message	15	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 08:49:54.915976
139	1	send_message	message	16	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 08:51:29.330349
140	1	send_message	message	17	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 08:58:21.579012
141	1	send_message	message	18	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-19 09:06:58.269855
142	1	send_message	message	19	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-19 09:08:18.821542
143	1	send_message	message	20	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-19 09:08:21.290743
144	1	send_message	message	21	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-19 09:08:22.883325
145	1	send_message	message	22	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:08:54.797823
146	1	send_message	message	23	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:10:53.954377
147	1	send_message	message	24	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:11:06.500694
148	1	send_message	message	25	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:14:10.063545
149	1	send_message	message	26	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:20:16.517245
150	1	send_message	message	27	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-19 09:43:07.254874
151	1	send_message	message	28	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:45:50.773015
152	1	send_message	message	29	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:45:54.096757
153	1	send_message	message	30	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:45:56.70323
154	1	send_message	message	31	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:59:02.07338
155	1	send_message	message	32	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 09:59:06.559923
156	1	cico_checkin	cico	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 10:43:47.688679
157	1	send_message	message	34	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 10:46:13.780903
158	1	send_message	message	35	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 10:46:35.326841
159	1	send_message	message	36	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 10:46:39.001428
160	1	create_conversation	conversation	7	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 11:29:22.282248
161	1	send_message	message	38	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 11:29:25.741292
162	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 12:42:13.973616
163	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 12:42:14.471118
164	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-03-19 12:56:59.804392
165	\N	login_failed_cico	session	\N	{"error": "Invalid credentials"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 13:16:38.77483
166	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 13:16:52.426151
167	1	create_conversation	conversation	8	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-19 13:17:05.139854
168	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 13:38:50.527569
169	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 13:38:56.167641
170	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 14:14:27.012253
171	1	send_message	message	39	\N	::1	curl/8.14.1	2026-03-19 14:14:40.869757
172	1	login	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-19 14:53:09.948585
173	1	delete_message	message	38	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-19 14:53:37.255076
174	1	logout	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-19 15:05:59.706433
175	1	login	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-19 15:09:44.903742
176	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:17:42.769132
177	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:17:42.97181
178	1	login_failed	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:17:47.530226
179	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:17:54.022702
180	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:17:58.29719
181	2	change_password	user	\N	\N	::1	curl/8.14.1	2026-03-19 17:17:58.444881
182	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:18:02.046347
183	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:19:01.594248
184	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:19:01.723605
185	3	login_failed	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:19:01.918541
186	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:24:52.626516
187	1	file_uploaded	file	3	{"fileName": "test-valid.jpg", "fileSize": 10, "mimeType": "image/jpeg"}	::1	curl/8.14.1	2026-03-19 17:24:52.708756
188	1	file_upload_blocked	file	\N	{"reason": "File content tidak sesuai dengan tipe 'image/jpeg'. Kemungkinan file dipalsukan.", "fileName": "test-fake.jpg", "mimeType": "image/jpeg"}	::1	curl/8.14.1	2026-03-19 17:24:52.754797
189	1	file_upload_blocked	file	\N	{"reason": "File SVG mengandung konten berbahaya (<script[\\\\s>])", "fileName": "test-evil.svg", "mimeType": "image/svg+xml"}	::1	curl/8.14.1	2026-03-19 17:24:52.841857
190	1	file_uploaded	file	4	{"fileName": "test-safe.svg", "fileSize": 101, "mimeType": "image/svg+xml"}	::1	curl/8.14.1	2026-03-19 17:24:52.893641
191	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:00.534494
192	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:00.66414
193	1	2fa_system_enabled	system	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:00.808449
194	1	2fa_setup_started	user	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:00.921502
195	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:10.38002
196	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:27.417871
197	1	2fa_setup_started	user	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:27.469554
198	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:46.808194
199	1	2fa_setup_started	user	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:46.867713
200	1	2fa_enabled	user	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:46.914059
201	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:47.061504
202	1	2fa_disabled	user	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:47.137801
203	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:47.214488
204	1	2fa_system_disabled	system	\N	\N	::1	curl/8.14.1	2026-03-19 17:31:47.25577
205	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:35:11.311079
206	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:35:11.428183
207	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:38:50.632008
208	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:39:02.133497
209	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:40:40.91451
210	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:40:46.302783
211	1	change_password	user	\N	\N	::1	curl/8.14.1	2026-03-19 17:40:46.554041
212	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:40:52.305145
213	1	create_user	user	10	\N	::1	curl/8.14.1	2026-03-19 17:40:52.521387
214	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:40:58.614457
215	2	login_failed	session	\N	{"failedAttempts": 1}	::1	curl/8.14.1	2026-03-19 17:47:24.666549
216	2	login_failed	session	\N	{"failedAttempts": 2}	::1	curl/8.14.1	2026-03-19 17:47:24.873988
217	2	login_failed	session	\N	{"failedAttempts": 3}	::1	curl/8.14.1	2026-03-19 17:47:24.985227
218	2	login_failed	session	\N	{"failedAttempts": 4}	::1	curl/8.14.1	2026-03-19 17:47:25.112105
219	2	login_failed	session	\N	{"failedAttempts": 5}	::1	curl/8.14.1	2026-03-19 17:47:25.240112
220	2	login_failed_account_locked	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:47:29.749266
221	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:47:35.652769
222	1	unlock_account	user	2	\N	::1	curl/8.14.1	2026-03-19 17:47:35.870402
223	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:47:41.181253
224	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:50:18.049232
225	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:50:24.27147
226	1	data_retention_executed	system	\N	{"auditLogsDeleted": 0, "cicoRecordsDeleted": 0, "loginAttemptsDeleted": 0}	::1	curl/8.14.1	2026-03-19 17:50:24.451338
227	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-19 17:50:30.538008
228	1	login_failed	session	\N	{"failedAttempts": 1}	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:12:34.618511
229	1	cico_checkout	cico	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-20 01:13:06.704466
230	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:13:46.837857
231	7	create_conversation	conversation	9	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:13:54.608865
232	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-20 01:13:59.331597
233	7	logout	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:14:09.541445
234	1	login_failed	session	\N	{"failedAttempts": 2}	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:14:30.118391
235	1	login_failed	session	\N	{"failedAttempts": 3}	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:14:48.018799
236	1	login_failed	session	\N	{"failedAttempts": 4}	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:14:53.507987
237	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-20 01:15:31.079906
238	2	login	session	\N	\N	::1	curl/8.14.1	2026-03-20 01:15:45.828393
239	2	reset_password	user	1	\N	::1	curl/8.14.1	2026-03-20 01:15:46.073181
240	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-20 01:15:50.916581
241	1	login	session	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:16:11.689902
242	1	cico_checkin	cico	\N	\N	::ffff:127.0.0.1	okhttp/4.12.0	2026-03-20 01:16:53.831686
243	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-20 07:36:32.794926
244	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-20 07:37:29.352971
245	1	file_uploaded	file	5	{"fileName": "test.txt", "fileSize": 10, "mimeType": "text/plain"}	::1	curl/8.14.1	2026-03-20 07:37:29.626472
262	1	send_message	message	40	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-20 14:30:04.845491
274	1	send_message	message	41	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-20 14:30:21.929285
276	1	send_message	message	42	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-20 14:32:13.47528
277	1	send_message	message	43	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-20 14:32:22.747959
278	1	send_message	message	44	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 01:54:13.216381
279	1	send_message	message	45	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 01:56:19.165119
280	1	send_message	message	46	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 01:56:30.115926
281	1	send_message	message	47	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 01:56:36.100305
282	1	pin_message	message	33	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 02:44:16.72607
283	1	create_conversation	conversation	10	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 03:39:16.273259
284	1	send_message	message	49	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 03:39:32.063305
285	1	delete_group	conversation	10	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 03:39:53.504374
286	1	send_message	message	50	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 04:01:31.388981
287	1	create_conversation	conversation	11	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 04:28:42.278156
288	1	send_message	message	51	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 04:32:43.213201
289	1	create_conversation	conversation	12	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 04:32:53.171644
290	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 04:51:43.74525
291	7	create_conversation	conversation	13	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 04:52:13.698279
292	7	send_message	message	53	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 04:52:42.422493
293	7	send_message	message	54	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 04:54:19.307518
294	7	create_conversation	conversation	14	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 04:56:27.195115
295	7	create_conversation	conversation	15	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 05:07:58.400403
296	7	cico_checkout	cico	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 05:08:12.171856
297	1	edit_message	message	42	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 05:09:41.298044
298	1	delete_message	message	42	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 05:09:46.331787
299	\N	login_failed_cico	session	\N	{"error": "Invalid credentials"}	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 14:48:45.473285
300	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 14:49:00.066998
301	1	logout	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 15:01:33.001658
302	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 15:03:46.650607
303	7	logout	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:04:34.860664
304	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:06:08.15668
305	7	logout	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:10:36.392477
306	1	login_failed	session	\N	{"failedAttempts": 1}	::ffff:127.0.0.1	curl/8.14.1	2026-03-21 15:10:45.080275
307	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:10:47.851622
308	1	login_failed	session	\N	{"failedAttempts": 1}	::ffff:127.0.0.1	curl/8.14.1	2026-03-21 15:10:50.058786
309	1	logout	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:15:25.304907
310	7	login_via_cico	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:15:36.826885
311	7	create_conversation	conversation	16	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:16:52.928986
313	7	send_message	message	55	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-21 15:16:56.714107
316	1	login	session	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 16:01:59.080304
317	1	send_message	message	56	\N	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 16:02:47.723538
320	1	login	session	\N	\N	::1	curl/8.14.1	2026-03-21 16:15:26.485358
321	1	cico_checkout	cico	\N	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-21 16:51:08.650183
322	\N	login_failed_cico	session	\N	{"error": "CICO request timeout - server not responding"}	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:10:42.386013
323	\N	login_failed_cico	session	\N	{"error": "CICO returned invalid response (status 500): Internal Server Error"}	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:10:49.8356
324	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:10:53.614682
325	1	login_failed	session	\N	{"failedAttempts": 1}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 11:11:18.740712
326	1	login	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 11:11:32.267368
327	1	logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 11:13:11.836912
328	1	login	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 11:13:33.298632
329	1	logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 11:14:45.627343
330	1	login	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 11:15:09.306726
331	7	send_message	message	57	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:49:26.582586
334	1	send_message	message	58	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 11:49:52.267223
337	7	send_message	message	59	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:50:26.289331
340	7	send_message	message	60	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:51:32.540418
342	7	send_message	message	61	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:52:11.074497
345	7	logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:55:12.703638
346	\N	login_failed_cico	session	\N	{"error": "CICO request timeout - server not responding"}	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:56:59.726404
347	\N	login_failed_cico	session	\N	{"error": "CICO returned invalid response (status 500): Internal Server Error"}	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:57:10.695514
348	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 11:57:16.705516
349	7	send_message	message	62	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 12:14:10.093813
351	7	send_message	message	63	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 12:15:30.949977
353	7	logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 12:16:11.319413
354	\N	login_failed_cico	session	\N	{"error": "CICO request timeout - server not responding"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 12:21:04.995372
355	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 12:21:28.179398
356	7	logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 12:35:43.927198
357	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 12:40:23.578573
358	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 12:44:52.179012
359	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 12:45:29.806517
360	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 12:46:05.833275
361	7	logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	2026-03-22 12:52:14.584308
362	1	login	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-22 12:59:31.619457
375	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 13:53:58.384399
376	7	login_via_cico	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 13:58:59.101773
377	\N	login_failed_cico	session	\N	{"error": "Invalid credentials"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 14:01:44.099251
378	1	login	session	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Replit/1.0.14 Chrome/124.0.6367.119 Electron/30.0.3 Safari/537.36	2026-03-22 14:01:51.066841
\.


--
-- Data for Name: canvas_board_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.canvas_board_members (id, board_id, user_id, role, added_at) FROM stdin;
\.


--
-- Data for Name: canvas_boards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.canvas_boards (id, name, conversation_id, created_by_id, thumbnail, created_at, updated_at, is_public) FROM stdin;
1	Test Board	\N	1	\N	2026-03-21 16:15:35.857776	2026-03-21 16:23:55.686	t
2	Testing	\N	1	\N	2026-03-21 16:26:50.666565	2026-03-21 16:27:29.201	t
3	Board Baru	\N	1	\N	2026-03-21 16:41:50.121526	2026-03-21 16:41:50.121526	t
\.


--
-- Data for Name: canvas_elements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.canvas_elements (id, board_id, element_type, x, y, width, height, rotation, points, content, style, z_index, created_by_id, created_at, updated_at) FROM stdin;
1	1	freehand	0	0	0	0	0	[[274.07501220703125, 165.4750099182129], [273.2749938964844, 165.4750099182129], [270.875, 166.27499771118164], [270.875, 167.8750343322754], [269.2749938964844, 169.4750099182129], [268.4750061035156, 170.27499771118164], [266.07501220703125, 173.4750099182129], [264.4750061035156, 178.27499771118164], [261.2749938964844, 185.4750099182129], [258.07501220703125, 192.67500686645508], [254.875, 199.87501907348633], [253.27499389648438, 208.67500686645508], [250.07501220703125, 220.67500686645508], [249.27499389648438, 232.67500686645508], [249.27499389648438, 243.87501907348633], [249.27499389648438, 255.87501907348633], [249.27499389648438, 268.6750068664551], [252.47500610351562, 279.8750190734863], [261.2749938964844, 298.2750129699707], [269.2749938964844, 307.8750190734863], [278.875, 315.8750190734863], [287.6750183105469, 323.8750190734863], [296.4750061035156, 329.4749946594238], [307.6750183105469, 336.6750679016113], [316.4750061035156, 341.4749946594238], [322.875, 346.2750129699707], [327.6750183105469, 350.2750129699707], [330.875, 354.2750129699707], [331.6750183105469, 359.8750190734863], [331.6750183105469, 363.8750190734863], [331.6750183105469, 369.4749946594238], [329.2749938964844, 378.2750129699707], [324.4750061035156, 386.2750129699707], [318.07501220703125, 393.4749946594238], [310.875, 399.8750190734863], [304.4750061035156, 405.4749946594238], [298.875, 409.4749946594238], [294.875, 412.6750679016113], [294.07501220703125, 414.2750129699707], [293.2749938964844, 414.2750129699707], [294.875, 414.2750129699707], [301.2749938964844, 414.2750129699707], [306.875, 414.2750129699707], [313.2749938964844, 414.2750129699707], [319.6750183105469, 413.4749946594238]]	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#1e1e1e", "strokeWidth": 2}	0	1	2026-03-21 16:23:53.247292	2026-03-21 16:23:53.247292
2	1	freehand	0	0	0	0	0	[[459.67498779296875, 199.07500076293945], [460.47503662109375, 198.2750129699707], [458.07501220703125, 199.87501907348633], [456.47503662109375, 202.2750129699707], [450.875, 210.2750129699707], [446.875, 218.2750129699707], [442.07501220703125, 228.67500686645508], [437.27508544921875, 238.2750129699707], [430.07501220703125, 250.2750129699707], [425.27508544921875, 261.4749946594238], [420.47503662109375, 272.6750068664551], [416.47503662109375, 283.8750190734863], [412.47503662109375, 294.2750129699707], [410.875, 302.2750129699707], [410.07501220703125, 309.4749946594238], [410.875, 314.2750129699707], [414.875, 320.6750068664551], [419.67498779296875, 324.6750068664551], [425.27508544921875, 328.6750068664551], [432.47503662109375, 332.6750068664551], [441.27508544921875, 335.8750190734863], [450.875, 336.6750679016113], [465.27508544921875, 339.8750190734863], [473.27508544921875, 341.4749946594238], [476.47503662109375, 341.4749946594238], [477.27508544921875, 341.4749946594238], [477.27508544921875, 342.2750129699707], [477.27508544921875, 344.6750679016113], [474.875, 347.8750190734863], [473.27508544921875, 351.8750190734863], [470.875, 355.8750190734863], [470.875, 360.6750679016113], [470.07501220703125, 365.4749946594238], [470.07501220703125, 373.4749946594238], [470.07501220703125, 380.6750679016113], [470.875, 386.2750129699707], [472.47503662109375, 392.6750679016113], [476.47503662109375, 400.6750679016113], [480.47503662109375, 407.8750190734863], [484.47503662109375, 413.4749946594238]]	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#1e1e1e", "strokeWidth": 2}	1	1	2026-03-21 16:23:53.973164	2026-03-21 16:23:53.973164
3	1	freehand	0	0	0	0	0	[[180.47500610351562, 447.8750190734863], [180.47500610351562, 448.6750679016113], [183.67501831054688, 447.8750190734863], [189.27499389648438, 445.4749946594238], [195.67501831054688, 439.07500076293945], [207.67501831054688, 430.2750129699707], [232.47500610351562, 409.4749946594238], [248.47500610351562, 395.8750190734863], [268.4750061035156, 379.8750190734863], [286.875, 366.2750129699707], [306.875, 353.4749946594238], [326.875, 339.8750190734863], [351.6750183105469, 326.2750129699707], [373.2751159667969, 314.2750129699707], [393.27508544921875, 303.07500076293945], [412.47503662109375, 294.2750129699707], [430.875, 286.2750129699707], [441.27508544921875, 281.4749946594238], [449.27508544921875, 278.2750129699707], [453.27508544921875, 277.4749946594238], [456.47503662109375, 275.8750190734863], [457.27508544921875, 275.8750190734863], [454.875, 276.6750068664551]]	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#1e1e1e", "strokeWidth": 2}	2	1	2026-03-21 16:23:54.788952	2026-03-21 16:23:54.788952
4	1	freehand	0	0	0	0	0	[[229.27499389648438, 511.07500076293945], [233.27499389648438, 507.07500076293945], [240.47500610351562, 501.47502517700195], [247.67501831054688, 494.2750129699707], [257.2749938964844, 486.2750129699707], [268.4750061035156, 477.47502517700195], [282.875, 466.2750129699707], [295.6750183105469, 457.47502517700195], [309.2749938964844, 447.8750190734863], [341.2751159667969, 427.8750190734863], [357.2751159667969, 419.8750190734863], [372.4750061035156, 411.07500076293945], [387.67498779296875, 403.07500076293945], [403.67498779296875, 395.07500076293945], [422.875, 387.07500076293945], [437.27508544921875, 381.4749946594238], [451.67498779296875, 375.8750190734863], [464.47503662109375, 370.2750129699707], [479.67498779296875, 365.4749946594238], [490.875, 361.4749946594238], [499.67498779296875, 359.07500076293945], [506.875, 355.8750190734863], [511.67498779296875, 355.07500076293945], [515.6749877929688, 354.2750129699707], [518.875, 353.4749946594238], [519.6749877929688, 351.8750190734863], [520.4750366210938, 351.8750190734863], [521.2750854492188, 351.8750190734863], [522.875, 351.07500076293945]]	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#1e1e1e", "strokeWidth": 2}	3	1	2026-03-21 16:23:55.333949	2026-03-21 16:23:55.333949
5	1	freehand	0	0	0	0	0	[[485.27508544921875, 381.4749946594238], [507.67498779296875, 370.2750129699707], [527.6749877929688, 361.4749946594238], [546.875, 353.4749946594238], [557.2750854492188, 347.8750190734863], [563.6749877929688, 346.2750129699707], [565.2750854492188, 343.8750190734863], [566.875, 343.07500076293945], [566.0750122070312, 343.07500076293945]]	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#1e1e1e", "strokeWidth": 2}	4	1	2026-03-21 16:23:55.683631	2026-03-21 16:23:55.683631
6	2	freehand	0	0	0	0	0	[[198.07501220703125, 252.67500686645508], [190.07501220703125, 247.87501907348633], [182.07501220703125, 242.2750129699707], [170.875, 235.07500076293945], [162.875, 230.2750129699707], [155.67501831054688, 224.67500686645508], [150.875, 220.67500686645508], [147.67501831054688, 215.07500076293945], [146.875, 211.07500076293945], [146.875, 202.2750129699707], [149.27499389648438, 190.27499771118164], [154.07501220703125, 176.67500686645508], [164.47500610351562, 163.07500076293945], [175.67501831054688, 147.87504959106445], [195.67501831054688, 131.07500076293945], [210.07501220703125, 120.67500686645508], [236.47500610351562, 107.87503433227539], [259.6750183105469, 99.07500076293945], [288.4750061035156, 91.07500076293945], [311.6750183105469, 88.67500686645508], [329.2749938964844, 87.87503433227539], [345.2751159667969, 89.47500991821289], [361.2751159667969, 96.67500686645508], [371.6750183105469, 104.67500686645508], [380.47503662109375, 115.07500076293945], [388.47503662109375, 128.67500686645508], [394.07501220703125, 146.27499771118164], [396.47503662109375, 162.27499771118164], [396.47503662109375, 178.27499771118164], [394.875, 195.07500076293945], [386.07501220703125, 215.07500076293945], [378.07501220703125, 228.67500686645508], [359.6750183105469, 247.07500076293945], [323.6750183105469, 273.4749946594238], [307.6750183105469, 280.6750068664551], [291.6750183105469, 284.6750068664551], [277.2749938964844, 286.2750129699707], [265.2749938964844, 286.2750129699707], [254.875, 286.2750129699707], [249.27499389648438, 286.2750129699707], [245.27499389648438, 283.07500076293945], [242.875, 279.07500076293945], [242.07501220703125, 274.2750129699707], [242.07501220703125, 267.07500076293945], [242.07501220703125, 256.6750068664551], [246.07501220703125, 247.07500076293945], [251.67501831054688, 236.67500686645508], [258.07501220703125, 226.2750129699707], [266.07501220703125, 216.67500686645508], [276.4750061035156, 210.2750129699707], [288.4750061035156, 203.87501907348633], [297.2749938964844, 202.2750129699707], [303.6750183105469, 199.87501907348633], [308.4750061035156, 199.07500076293945], [312.4750061035156, 199.07500076293945], [315.6750183105469, 199.07500076293945], [316.4750061035156, 200.67500686645508], [319.6750183105469, 203.07500076293945], [319.6750183105469, 204.67500686645508], [319.6750183105469, 205.47499465942383]]	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#1e1e1e", "strokeWidth": 2}	0	1	2026-03-21 16:26:52.728602	2026-03-21 16:26:52.728602
7	2	rectangle	117.27501	46.275005	123.2	186.4	0	\N	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#1e1e1e", "strokeWidth": 2}	1	1	2026-03-21 16:27:04.358961	2026-03-21 16:27:04.358961
8	2	sticky_note	63.675003	26.275005	200	150	0	\N	testing	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#e03131", "strokeWidth": 2}	2	1	2026-03-21 16:27:24.805603	2026-03-21 16:27:24.805603
9	2	rectangle	478.075	50.275005	292	244	0	\N	\N	{"opacity": 1, "fontSize": 16, "fillColor": "transparent", "fontFamily": "sans-serif", "strokeColor": "#e03131", "strokeWidth": 2}	3	1	2026-03-21 16:27:29.197965	2026-03-21 16:27:29.197965
\.


--
-- Data for Name: cico_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cico_logs (id, employee_id, action, location, created_at, type) FROM stdin;
1	EMP001	checkout	\N	2026-03-16 15:50:55.488056	\N
2	EMP001	checkout	\N	2026-03-16 15:51:53.529089	\N
3	EMP007	checkin	Kantor	2026-03-18 05:41:56.847698	office
4	EMP001	checkin	\N	2026-03-19 10:43:47.678175	office
5	EMP001	checkout	\N	2026-03-20 01:13:06.699137	\N
6	EMP001	checkin	Kantor	2026-03-20 01:16:53.829191	office
7	EMP007	checkout	\N	2026-03-21 05:08:12.168251	\N
8	EMP001	checkout	\N	2026-03-21 16:51:08.643361	\N
\.


--
-- Data for Name: cico_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cico_status (id, employee_id, status, check_in_time, check_out_time, location, updated_at) FROM stdin;
2	EMP002	present	2026-03-16 03:54:18.28	\N	Office	2026-03-16 05:54:18.28
3	EMP003	wfh	2026-03-16 01:54:18.28	\N	WFH	2026-03-16 05:54:18.28
4	EMP004	break	2026-03-16 00:54:18.28	\N	Office	2026-03-16 05:54:18.28
5	EMP005	absent	\N	\N	\N	2026-03-16 05:54:18.28
6	EMP006	present	2026-03-16 04:54:18.28	\N	Office	2026-03-16 05:54:18.28
7	EMP007	absent	2026-03-18 05:41:56.841	2026-03-21 05:08:12.165	Kantor	2026-03-21 05:08:12.165
1	EMP001	absent	2026-03-20 01:16:53.826	2026-03-21 16:51:08.612	Kantor	2026-03-21 16:51:08.612
\.


--
-- Data for Name: compliance_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_flags (id, message_id, conversation_id, user_id, flag_type, pii_types, original_content, redacted_content, severity, status, reviewed_by_id, reviewed_at, review_note, created_at) FROM stdin;
1	50	7	1	pii_detected	["phone_id"]	ini nomor saya 0856374747	ini nomor saya ********47	high	pending	\N	\N	\N	2026-03-21 04:01:31.388
\.


--
-- Data for Name: conversation_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversation_members (id, conversation_id, user_id, role, is_pinned, is_muted, last_read_at, joined_at, cleared_at) FROM stdin;
2	1	2	member	f	f	\N	2026-03-16 05:54:18.28	\N
3	1	3	member	f	f	\N	2026-03-16 05:54:18.28	\N
4	1	4	member	f	f	\N	2026-03-16 05:54:18.28	\N
5	1	5	member	f	f	\N	2026-03-16 05:54:18.28	\N
6	1	6	member	f	f	\N	2026-03-16 05:54:18.28	\N
10	3	2	member	f	f	\N	2026-03-16 05:54:18.28	\N
29	11	10	member	f	f	\N	2026-03-21 04:28:42.274	\N
8	2	4	member	f	f	2026-03-16 07:48:09.373	2026-03-16 05:54:18.28	\N
12	4	3	member	f	f	\N	2026-03-16 07:49:44.515	\N
11	4	4	member	f	f	2026-03-16 07:49:44.923	2026-03-16 07:49:44.515	\N
13	5	2	admin	f	f	\N	2026-03-19 10:44:16.493392	\N
14	5	6	member	f	f	\N	2026-03-19 10:44:16.493392	\N
40	16	1	member	f	f	2026-03-22 14:17:22.356	2026-03-21 15:16:52.916	\N
31	12	8	member	f	f	\N	2026-03-21 04:32:53.168	\N
16	6	2	admin	f	f	\N	2026-03-19 10:57:58.742093	\N
17	6	6	member	f	f	\N	2026-03-19 10:57:58.742093	\N
9	3	1	member	f	f	2026-03-20 14:30:25.771	2026-03-16 05:54:18.28	\N
30	12	1	member	f	f	2026-03-21 04:33:26.9	2026-03-21 04:32:53.168	\N
33	13	3	member	f	f	\N	2026-03-21 04:52:13.69	\N
34	13	10	member	f	f	\N	2026-03-21 04:52:13.69	\N
35	14	7	member	f	f	2026-03-22 12:35:14.176	2026-03-21 04:56:27.184	\N
15	5	1	member	f	f	2026-03-21 05:16:55.361	2026-03-19 10:44:16.493392	\N
20	7	6	member	f	f	\N	2026-03-19 11:29:22.277	\N
24	9	10	member	f	f	\N	2026-03-20 01:13:54.603	\N
1	1	1	admin	f	f	2026-03-21 05:09:27.664	2026-03-16 05:54:18.28	\N
32	13	7	admin	f	f	2026-03-22 12:09:17.103	2026-03-21 04:52:13.69	\N
36	14	3	member	f	f	\N	2026-03-21 04:56:27.184	\N
7	2	1	admin	f	f	2026-03-21 04:57:06.983	2026-03-16 05:54:18.28	\N
21	8	1	member	f	f	2026-03-21 03:56:51.042	2026-03-19 13:17:05.136	\N
18	6	1	member	f	f	2026-03-21 03:56:53.551	2026-03-19 10:57:58.742093	\N
37	15	7	member	f	f	2026-03-22 11:51:47.847	2026-03-21 05:07:58.397	\N
23	9	7	member	f	f	2026-03-22 11:51:53.66	2026-03-20 01:13:54.603	\N
28	11	1	member	f	f	2026-03-21 05:04:46.513	2026-03-21 04:28:42.274	\N
22	8	4	member	f	f	\N	2026-03-19 13:17:05.136	\N
39	16	7	member	f	f	2026-03-22 12:16:03.192	2026-03-21 15:16:52.916	\N
19	7	1	member	f	f	2026-03-21 16:02:35.345	2026-03-19 11:29:22.277	\N
38	15	4	member	f	f	\N	2026-03-21 05:07:58.397	\N
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, type, name, description, avatar_url, created_by_id, created_at, updated_at, whatsapp_contact_phone, whatsapp_contact_name, wa_status, assigned_to_id) FROM stdin;
4	direct	\N	\N	\N	4	2026-03-16 07:49:44.480497	2026-03-16 07:49:44.48	\N	\N	unassigned	\N
2	group	Tim IT	Internal IT department channel	\N	1	2026-03-16 05:54:18.292639	2026-03-19 09:45:50.772	\N	\N	unassigned	\N
8	direct	\N	\N	\N	1	2026-03-19 13:17:05.133505	2026-03-19 13:17:05.133	\N	\N	unassigned	\N
1	group	General	Percakapan umum seluruh karyawan	\N	1	2026-03-16 05:54:18.285758	2026-03-20 14:30:04.844	\N	\N	unassigned	\N
3	direct	\N	\N	\N	1	2026-03-16 05:54:18.298917	2026-03-20 14:30:21.921	\N	\N	unassigned	\N
5	whatsapp	WhatsApp: 6281234567890	Chat WhatsApp dengan 6281234567890 (6281234567890)	\N	1	2026-03-19 10:44:16.486435	2026-03-20 14:32:13.474	6281234567890	6281234567890	unassigned	\N
6	whatsapp	WhatsApp: +6281234567890	Chat WhatsApp dengan +6281234567890 (+6281234567890)	\N	1	2026-03-19 10:57:58.734017	2026-03-21 01:56:30.115	+6281234567890	+6281234567890	assigned	1
7	direct	\N	\N	\N	1	2026-03-19 11:29:22.155529	2026-03-21 04:01:31.388	\N	\N	unassigned	\N
11	direct	\N	\N	\N	1	2026-03-21 04:28:42.244718	2026-03-21 04:32:43.212	\N	\N	unassigned	\N
12	direct	\N	\N	\N	1	2026-03-21 04:32:53.165118	2026-03-21 04:32:53.164	\N	\N	unassigned	\N
9	direct	\N	\N	\N	7	2026-03-20 01:13:54.598503	2026-03-21 04:52:42.422	\N	\N	unassigned	\N
13	group	test	\N	\N	7	2026-03-21 04:52:13.655479	2026-03-21 04:54:19.307	\N	\N	unassigned	\N
15	direct	\N	\N	\N	7	2026-03-21 05:07:58.394624	2026-03-21 05:07:58.394	\N	\N	unassigned	\N
14	direct	\N	\N	\N	7	2026-03-21 04:56:27.182308	2026-03-22 12:14:10.093	\N	\N	unassigned	\N
16	direct	\N	\N	\N	7	2026-03-21 15:16:52.903319	2026-03-22 12:15:30.948	\N	\N	unassigned	\N
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_attempts (id, user_id, ip_address, success, created_at) FROM stdin;
25	1	34.24.89.147	f	2026-03-21 15:10:50.054472
\.


--
-- Data for Name: message_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_favorites (id, message_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: message_reactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_reactions (id, message_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: message_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_reads (id, message_id, user_id, read_at) FROM stdin;
1	4	1	2026-03-20 14:30:02.437486
2	2	1	2026-03-20 14:30:02.454315
3	1	1	2026-03-20 14:30:02.45473
4	3	1	2026-03-20 14:30:02.456007
5	5	1	2026-03-20 14:30:02.723198
6	6	1	2026-03-20 14:30:02.745247
7	12	1	2026-03-20 14:30:02.746095
8	7	1	2026-03-20 14:30:02.746791
9	13	1	2026-03-20 14:30:02.997071
10	14	1	2026-03-20 14:30:03.181861
11	15	1	2026-03-20 14:30:03.20295
12	22	1	2026-03-20 14:30:03.217166
13	26	1	2026-03-20 14:30:03.271056
14	29	1	2026-03-20 14:30:03.280038
15	31	1	2026-03-20 14:30:03.281073
16	32	1	2026-03-20 14:30:03.45593
17	40	1	2026-03-20 14:30:09.33408
18	9	1	2026-03-20 14:30:19.418022
19	10	1	2026-03-20 14:30:19.418229
20	18	1	2026-03-20 14:30:19.421083
21	8	1	2026-03-20 14:30:19.428801
22	19	1	2026-03-20 14:30:19.440593
23	20	1	2026-03-20 14:30:19.686537
24	21	1	2026-03-20 14:30:19.695395
25	23	1	2026-03-20 14:30:19.696829
26	24	1	2026-03-20 14:30:19.713521
27	30	1	2026-03-20 14:30:19.727164
28	41	1	2026-03-20 14:30:26.403071
29	1	7	2026-03-21 15:16:53.623508
30	2	7	2026-03-21 15:16:53.628052
31	3	7	2026-03-21 15:16:53.631284
32	4	7	2026-03-21 15:16:53.634827
33	5	7	2026-03-21 15:16:53.637725
34	6	7	2026-03-21 15:16:53.640719
35	7	7	2026-03-21 15:16:53.643158
36	8	7	2026-03-21 15:16:53.646175
37	9	7	2026-03-21 15:16:53.649422
38	10	7	2026-03-21 15:16:53.652591
39	11	7	2026-03-21 15:16:53.655454
40	12	7	2026-03-21 15:16:53.658145
41	13	7	2026-03-21 15:16:53.660668
42	14	7	2026-03-21 15:16:53.663694
43	15	7	2026-03-21 15:16:53.666275
44	16	7	2026-03-21 15:16:53.668655
45	17	7	2026-03-21 15:16:53.670746
46	18	7	2026-03-21 15:16:53.67329
47	19	7	2026-03-21 15:16:53.675877
48	20	7	2026-03-21 15:16:53.678345
49	21	7	2026-03-21 15:16:53.680874
50	22	7	2026-03-21 15:16:53.683387
51	23	7	2026-03-21 15:16:53.685919
52	24	7	2026-03-21 15:16:53.688152
53	25	7	2026-03-21 15:16:53.690503
54	26	7	2026-03-21 15:16:53.692998
55	27	7	2026-03-21 15:16:53.695752
56	28	7	2026-03-21 15:16:53.698094
57	29	7	2026-03-21 15:16:53.700403
58	30	7	2026-03-21 15:16:53.70355
59	31	7	2026-03-21 15:16:53.70598
60	32	7	2026-03-21 15:16:53.708546
61	34	7	2026-03-21 15:16:53.710268
62	35	7	2026-03-21 15:16:53.712671
63	36	7	2026-03-21 15:16:53.714985
64	37	7	2026-03-21 15:16:53.71742
65	39	7	2026-03-21 15:16:53.719776
66	38	7	2026-03-21 15:16:53.722206
67	40	7	2026-03-21 15:16:53.724378
68	41	7	2026-03-21 15:16:53.726777
69	43	7	2026-03-21 15:16:53.729188
70	44	7	2026-03-21 15:16:53.730855
71	45	7	2026-03-21 15:16:53.733054
72	46	7	2026-03-21 15:16:53.735508
73	47	7	2026-03-21 15:16:53.738066
74	33	7	2026-03-21 15:16:53.739965
75	50	7	2026-03-21 15:16:53.742277
76	51	7	2026-03-21 15:16:53.744828
77	52	7	2026-03-21 15:16:53.747343
78	53	7	2026-03-21 15:16:53.749208
79	54	7	2026-03-21 15:16:53.751548
80	42	7	2026-03-21 15:16:53.753298
81	55	7	2026-03-21 15:25:45.949559
82	25	1	2026-03-21 15:28:44.43572
83	27	1	2026-03-21 15:28:44.439276
84	11	1	2026-03-21 15:28:44.442613
85	39	1	2026-03-21 15:28:44.445503
86	17	1	2026-03-21 15:28:44.44878
87	33	1	2026-03-21 15:28:44.452148
88	34	1	2026-03-21 15:28:44.462427
89	47	1	2026-03-21 15:28:44.465386
90	46	1	2026-03-21 15:28:44.46865
91	52	1	2026-03-21 15:28:44.47176
92	37	1	2026-03-21 15:28:44.474916
93	55	1	2026-03-21 15:28:44.477939
94	38	1	2026-03-21 15:28:44.480981
95	28	1	2026-03-21 15:28:44.483577
96	50	1	2026-03-21 15:28:44.485764
97	51	1	2026-03-21 15:28:44.488841
98	42	1	2026-03-21 15:28:44.491944
99	16	1	2026-03-21 15:28:44.494648
100	54	1	2026-03-21 15:28:44.497373
101	36	1	2026-03-21 15:28:44.500273
102	53	1	2026-03-21 15:28:44.503456
103	44	1	2026-03-21 15:28:44.50608
104	45	1	2026-03-21 15:28:44.508867
105	43	1	2026-03-21 15:28:44.511836
106	35	1	2026-03-21 15:28:44.5144
107	56	1	2026-03-21 16:02:48.073348
108	56	7	2026-03-21 16:02:48.202297
109	57	7	2026-03-22 11:49:26.893011
110	57	1	2026-03-22 11:49:40.406974
111	58	1	2026-03-22 11:49:52.701469
112	58	7	2026-03-22 11:49:52.862623
113	59	1	2026-03-22 11:50:26.570027
114	59	7	2026-03-22 11:50:26.81013
115	60	7	2026-03-22 11:51:32.885409
116	61	7	2026-03-22 11:52:11.454415
117	60	1	2026-03-22 11:52:51.057955
118	61	1	2026-03-22 11:52:51.061324
119	62	7	2026-03-22 12:14:10.431495
120	63	7	2026-03-22 12:15:31.413537
121	55	1	2026-03-22 13:07:31.752639
122	56	1	2026-03-22 13:07:31.756781
123	57	1	2026-03-22 13:07:32.025541
124	58	1	2026-03-22 13:07:32.039641
125	59	1	2026-03-22 13:07:32.295731
126	63	1	2026-03-22 13:07:32.304283
127	55	1	2026-03-22 13:07:49.459736
128	58	1	2026-03-22 13:07:49.459906
129	56	1	2026-03-22 13:07:49.462597
130	57	1	2026-03-22 13:07:49.466516
131	59	1	2026-03-22 13:07:49.666366
132	63	1	2026-03-22 13:07:49.741863
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, conversation_id, sender_id, content, type, reply_to_id, is_pinned, is_edited, is_deleted, deleted_at, edited_at, original_content, created_at, wa_message_id, is_from_whatsapp) FROM stdin;
1	1	1	Selamat datang di CorpChat! Platform komunikasi resmi karyawan kita. 🎉	text	\N	f	f	f	\N	\N	\N	2026-03-16 03:54:18.28	\N	f
2	1	2	Terima kasih! Akhirnya ada platform chat yang terintegrasi CICO. Sangat membantu!	text	\N	f	f	f	\N	\N	\N	2026-03-16 03:59:18.28	\N	f
3	1	4	Bagus sekali! Mudah-mudahan produktivitas tim kita semakin meningkat 💪	text	\N	f	f	f	\N	\N	\N	2026-03-16 04:04:18.28	\N	f
4	1	3	Saya suka fitur status kehadiran-nya. Langsung tahu siapa yang sedang online atau tidak.	text	\N	f	f	f	\N	\N	\N	2026-03-16 04:09:18.28	\N	f
5	1	5	Ada yang tahu cara set Do Not Disturb? Kalau lagi fokus kerja bisa diganggu terus 😅	text	\N	f	f	f	\N	\N	\N	2026-03-16 04:14:18.28	\N	f
6	1	1	Fitur DND akan segera hadir. Untuk sementara bisa mute notifikasi dari pengaturan profil.	text	\N	f	f	f	\N	\N	\N	2026-03-16 04:19:18.28	\N	f
7	1	6	Team, ada meeting standup jam 9 pagi ya. Jangan lupa hadir!	text	\N	f	f	f	\N	\N	\N	2026-03-16 04:24:18.28	\N	f
8	3	1	Halo Budi, ada waktu untuk review kebijakan baru dari IT Security?	text	\N	f	f	f	\N	\N	\N	2026-03-16 05:24:18.28	\N	f
9	3	2	Tentu, saya sudah membaca draftnya. Ada beberapa poin yang perlu didiskusikan.	text	\N	f	f	f	\N	\N	\N	2026-03-16 05:29:18.28	\N	f
10	3	1	Oke, kita meeting besok jam 10 ya.	text	\N	f	f	f	\N	\N	\N	2026-03-16 05:34:18.28	\N	f
11	2	4	test	text	\N	f	f	f	\N	\N	\N	2026-03-16 07:48:08.971	\N	f
12	1	1	Tetesting	text	\N	f	f	f	\N	\N	\N	2026-03-19 08:46:03.553	\N	f
13	1	1	testing	text	\N	f	f	f	\N	\N	\N	2026-03-19 08:48:04.726	\N	f
14	1	1	asfasdfasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 08:48:11.795	\N	f
15	1	1	testing lagi	text	\N	f	f	f	\N	\N	\N	2026-03-19 08:49:54.876	\N	f
16	2	1	asdfasfa	text	\N	f	f	f	\N	\N	\N	2026-03-19 08:51:29.296	\N	f
17	2	1	fuckk	text	\N	f	f	f	\N	\N	\N	2026-03-19 08:58:21.571	\N	f
18	3	1	performancenya payah	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:06:58.227	\N	f
19	3	1	dvasdfadsfasdf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:08:18.804	\N	f
20	3	1	asdfasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:08:21.254	\N	f
21	3	1	asfasfasfasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:08:22.876	\N	f
22	1	1	asfasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:08:54.79	\N	f
23	3	1	fasdfasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:10:53.945	\N	f
24	3	1	asfasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:11:06.466	\N	f
25	2	1	cxvxzcvzxcv	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:14:10.049	\N	f
26	1	1	asdfasdfasfd	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:20:16.502	\N	f
27	2	1	tesa	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:43:06.922	\N	f
28	2	1	gfdgsdg	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:45:50.767	\N	f
29	1	1	asfaf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:45:54.082	\N	f
30	3	1	asfafasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:45:56.699	\N	f
31	1	1	\N	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:59:02.048	\N	f
32	1	1	😋	text	\N	f	f	f	\N	\N	\N	2026-03-19 09:59:06.555	\N	f
34	5	1	test fgasfd	text	\N	f	f	f	\N	\N	\N	2026-03-19 10:46:13.776	\N	f
35	5	1	fasdfasf	text	\N	f	f	f	\N	\N	\N	2026-03-19 10:46:35.315	\N	f
36	5	1	😈	text	\N	f	f	f	\N	\N	\N	2026-03-19 10:46:38.996	\N	f
37	6	1	test pesan	text	\N	f	f	f	\N	\N	\N	2026-03-19 10:57:58.744	SM999	t
39	6	1	Ini test WhatsApp send dari CurCol 🚀	text	\N	f	f	f	\N	\N	\N	2026-03-19 14:14:40.857	\N	f
38	7	1	\N	text	\N	f	f	t	\N	\N	\N	2026-03-19 11:29:25.736	\N	f
40	1	1	5462562345	text	\N	f	f	f	\N	\N	\N	2026-03-20 14:30:04.838	\N	f
41	3	1	testing	text	\N	f	f	f	\N	\N	\N	2026-03-20 14:30:21.918	\N	f
43	6	1	asfasf	text	\N	f	f	f	\N	\N	\N	2026-03-20 14:32:22.744	\N	f
44	6	1	adwgasdfasfd	text	\N	f	f	f	\N	\N	\N	2026-03-21 01:54:13.207	\N	f
45	7	1	4444	text	\N	f	f	f	\N	\N	\N	2026-03-21 01:56:19.16	\N	f
46	6	1	5555	text	\N	f	f	f	\N	\N	\N	2026-03-21 01:56:30.111	\N	f
47	7	1	ddddd	text	\N	f	f	f	\N	\N	\N	2026-03-21 01:56:36.095	\N	f
33	5	1	test	text	\N	t	f	f	\N	\N	\N	2026-03-19 10:44:16.499	SM123	t
50	7	1	ini nomor saya 0856374747	text	\N	f	f	f	\N	\N	\N	2026-03-21 04:01:31.384	\N	f
51	11	1	test	text	\N	f	f	f	\N	\N	\N	2026-03-21 04:32:43.209	\N	f
52	13	7	Joni Santoso membuat grup "test"	system	\N	f	f	f	\N	\N	\N	2026-03-21 04:52:13.694	\N	f
53	9	7	tesrgsb	text	\N	f	f	f	\N	\N	\N	2026-03-21 04:52:42.418	\N	f
54	13	7	saya gak bisa liat detil group	text	\N	f	f	f	\N	\N	\N	2026-03-21 04:54:19.303	\N	f
42	5	1	\N	text	\N	f	t	t	\N	2026-03-21 05:09:41.293	\N	2026-03-20 14:32:13.457	\N	f
55	16	7	test	text	\N	f	f	f	\N	\N	\N	2026-03-21 15:16:56.709	\N	f
56	16	1	cesffgg	text	\N	f	f	f	\N	\N	\N	2026-03-21 16:02:47.719	\N	f
57	16	7	What is your name ?	text	\N	f	f	f	\N	\N	\N	2026-03-22 11:49:26.576	\N	f
58	16	1	what is your name ?	text	\N	f	f	f	\N	\N	\N	2026-03-22 11:49:52.263	\N	f
59	16	7	siapa nama anda?	text	\N	f	f	f	\N	\N	\N	2026-03-22 11:50:26.285	\N	f
60	14	7	tidak paham	text	\N	f	f	f	\N	\N	\N	2026-03-22 11:51:32.536	\N	f
61	14	7	apa yang terjadi?	text	\N	f	f	f	\N	\N	\N	2026-03-22 11:52:11.063	\N	f
62	14	7	apa itu	text	\N	f	f	f	\N	\N	\N	2026-03-22 12:14:10.058	\N	f
63	16	7	makan malam dimana ?	text	\N	f	f	f	\N	\N	\N	2026-03-22 12:15:30.942	\N	f
\.


--
-- Data for Name: offline_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offline_queue (id, user_id, conversation_id, content, type, attachment_ids, reply_to_id, status, retry_count, error, created_at, synced_at) FROM stdin;
\.


--
-- Data for Name: push_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.push_tokens (id, user_id, token, platform, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, token, expires_at, created_at, refresh_token, refresh_expires_at) FROM stdin;
1	1	725b3b4761a7556ab89b010b24efaa89c62b293e2c18a0351735c9068b1b3714a5f925ed682c064d82b514830e1f10b5	2026-03-23 06:10:01.448	2026-03-16 06:10:01.449938	\N	\N
2	1	9fa151ae6ad6c66ca4372ce2759142b64b91ec9fb5f2f71d265596aa0ad67bd491abcd0b90360a215490edd0fa040616	2026-03-23 06:10:12.032	2026-03-16 06:10:12.033312	\N	\N
3	1	b8acd97d957f9153782bc5d1107fc6baef46ece5e41899663f929457c7402655a9bbbd2079ea77d952745292a132bc92	2026-03-23 07:44:44.571	2026-03-16 07:44:44.572575	\N	\N
4	1	cc6e6fe609ba2e1dd5d6d9f555f37c35b6bc93144fd55d2e8ffa826e44477ae99ad69175310cf3d736902497d143e3bc	2026-03-23 07:44:59.791	2026-03-16 07:44:59.792155	\N	\N
5	1	72bc4f5947dfd44baedb74f6e544276f4adf73bc8c7196f2e5a7fadd6427ecd36989fa37b9ab7e82965aa2a4c7229d11	2026-03-23 07:47:09.853	2026-03-16 07:47:09.853739	\N	\N
6	4	1619818456ed4a9c123713e06a2a9de7c528b1dcf290bdc18b7da82798693b5c9e534e9bb8c37d00b90c8b17216b2ac8	2026-03-23 07:47:41.923	2026-03-16 07:47:41.924032	\N	\N
7	1	68be350c3f169a0b075b74f66cbc0b1edacca045ee5ec44f87e19490236e1bec28bcf2c9bf16feb6a411d0c13e0aa102	2026-03-23 09:37:01.767	2026-03-16 09:37:01.767719	\N	\N
8	1	c6169ffcb972b691ee1934f9f7996aa38dd2026b25c554ead3d6d6b5ee91bc0d3913e24b9711752913be2d4eeac7be3e	2026-03-23 09:37:09.257	2026-03-16 09:37:09.25761	\N	\N
9	1	5aefd83d164ea4db61625e53e814c41ecda838aea144d340d3e87aeb95f818b133f83cba1018fe7065ee42a3bd1a0d2a	2026-03-23 09:39:36.991	2026-03-16 09:39:36.994317	\N	\N
10	1	7279415c880cf7739e44813fc5b110823e7a49863242254f83f5d2dc45794bd9547e8e3f2aa7dcda060214de8e00c913	2026-03-23 09:39:38.649	2026-03-16 09:39:38.649937	\N	\N
11	1	6e139837bcd26b7bb729e9fe25f2f1574322a74bef5f18c52b9de0b3d223577c2c98f7b426fac30b59490d0ae1ca118f	2026-03-23 09:39:45.176	2026-03-16 09:39:45.17732	\N	\N
12	1	0d69cf47560c737d18e746ecf631af329c36d9838b089a7815fe596bddeb2f315d9cd1c732639b63115bba9c45f10e4a	2026-03-23 09:42:01.96	2026-03-16 09:42:01.96098	\N	\N
13	1	81eb2e4360f83e24aacaa1c01dace40ccc46ad66e567ee62bef4d316a463637150419bb803628e6887dab0bf0816be7f	2026-03-23 15:24:13.487	2026-03-16 15:24:13.489468	\N	\N
14	1	c8e93bd2752d947fa8e828e2409bf337c1e6c997de8dc8fbab606473c0c2d8c84c81894d35ebd68bb9bf5084a5f26f3d	2026-03-23 15:24:20.98	2026-03-16 15:24:20.98084	\N	\N
15	1	84f192863be591b9494355f62d5cb4003a3f5fa8d23b4976a0202b378a4ed08670b65615ee0beebb871067986df9a494	2026-03-23 15:24:29.116	2026-03-16 15:24:29.117163	\N	\N
16	1	36e42cc4722eba71875523729c88f079e945499bace24e6c8a9901d7d3bf0ff9e5a2977fcce5957ebf3991ef7512520e	2026-03-23 15:34:19.925	2026-03-16 15:34:19.92702	\N	\N
17	1	90ae223e4c716b6f94328635c27d3162992c64b49331db707cb094d1106afb4c31416a7ac53620532e39f3598375fbcd	2026-03-23 15:34:28.681	2026-03-16 15:34:28.681662	\N	\N
18	1	2f4982f57882ed940a3334057781fda1b0a608f59a307ee609d5167a94413462d4710a247f17a21cfaecb9966e129b8d	2026-03-23 15:34:37.386	2026-03-16 15:34:37.387335	\N	\N
19	1	e370545501da344bb9b65afa4fa4682c8793becdf0675dad00a736b3a9f758826ae9b1ece32df14ab5b4b3846b4def3f	2026-03-23 15:49:47.568	2026-03-16 15:49:47.569055	\N	\N
20	1	438bcbb6a41d85aaf9f76bc93d396056fe00ebe5160d7294fa31740c8cb710d5b4c7e40a347f18837c30e86c83c1c779	2026-03-23 15:56:17.374	2026-03-16 15:56:17.375667	\N	\N
21	7	a4aba4e16b2bfc59c54c552ecf09e1cda0b60223aa2794c0263970dde4b43b0401ba37fabbc98668acff403201b745ee	2026-03-23 15:56:22.742	2026-03-16 15:56:22.743492	\N	\N
22	1	b986abcd71c08d445c94e5c4c8eae43efde2bd9b96652b741ef0f376915fadfe01391ed16a834e1e170271f9d8a9c04a	2026-03-23 15:59:55.46	2026-03-16 15:59:55.460709	\N	\N
23	1	a2f0d8eeebe49b7c329eccbe14fc8a2f7eef4fd433f9a3b6dd63074ec58bfa762cb962f0d65a552498bced579f4a48e6	2026-03-23 16:05:13.298	2026-03-16 16:05:13.300308	\N	\N
24	1	1f72db0f31379bde2b6ca77cb3731b7e6f4cb86e949f6ebd1399b99f10e8c6de002f2e41258891d9b2660c9dfb40df60	2026-03-24 17:15:41.955	2026-03-17 17:15:41.956302	\N	\N
25	1	ea574463ce28d907aa8682ce0a53ca3a553fb52c0d409a483618548bf8ffecadf88757d649d66f74c9200dd49283ebf0	2026-03-24 17:19:29.365	2026-03-17 17:19:29.367306	\N	\N
26	1	daeee2ccd438eb582880956936c0d9a7be2a86f88aa11a845c7fd1a253d713bba54ab0803cebb0fada1774c692de8aff	2026-03-24 17:45:19.671	2026-03-17 17:45:19.67251	\N	\N
27	1	332272d5d529ddd282241f04e8a1d0c468d72b3482683d9e4832d1a74960db671d742b0f16343bfb33b524d3c62cd64a	2026-03-24 17:48:05.037	2026-03-17 17:48:05.038059	\N	\N
28	1	2c895e74156e07a431366a91ce445a9ae4f11a3cb093d1641f5d314a94d98cb1c2b0e2c56927504efdaeda9cda5754ea	2026-03-24 17:49:38.189	2026-03-17 17:49:38.190078	\N	\N
29	1	42847bc8a6fffadc128a52c7ec523ee5d554c63fe9f94eff886798af670348db923e89064cb36edabe61b0ab400b5f06	2026-03-24 23:52:28.388	2026-03-17 23:52:28.389141	\N	\N
62	1	d80ce47f27bc2d483dd38aa4e4551527b480a2ec21fc0f1713fddf42554596c5f4180c748207f98ad1c964cb57d13614	2026-03-25 00:03:36.335	2026-03-18 00:03:36.336712	\N	\N
63	1	60af7237978d7fe9f8a2b5435a4c4ac5424cf1a4f6b126db64917696a3a45986f4dfa8031f5c59637d34608bea95cf10	2026-03-25 00:08:53.002	2026-03-18 00:08:53.002781	\N	\N
96	7	002baff7138f105ed5689c723a98c16d11b97dad7d5b4cdc3d08e6f01d1eb3c17c71f62ecc8f619cb9e9be14e966a0e2	2026-03-25 00:42:29.505	2026-03-18 00:42:29.506556	\N	\N
97	7	3d08fdf60f10509b4dd67efaf778c29df1d32a9708212991cf9d6cea83d177f790102841860ac950838d359039e95fe7	2026-03-25 05:34:07.673	2026-03-18 05:34:07.675763	\N	\N
98	7	c2b8c7d86b5b4aa900394a2bc22de76ac6f258427d6972afb960f9dc81dff41a35f0a61398fd3a496ca31c81b64b794d	2026-03-25 05:41:12.363	2026-03-18 05:41:12.363874	\N	\N
99	1	b379c5c1b214e8daaab58737f085ea6b10aeb7ede258753ecc879791490fedf3b1356fdbc325c52681ca6cbe9300690f	2026-03-25 05:50:04.909	2026-03-18 05:50:04.910262	\N	\N
100	1	c367f8b21e0772475463d32c3b2ff7e9c08e366feae7f593f97480b059296d42f7c737a70e6818ca1e7003d9993b00ea	2026-03-25 05:50:10.038	2026-03-18 05:50:10.039314	\N	\N
101	1	0ec125e9f5b7e523ed1d32766d0c65b007d538b8740046c7f1a8615c27e383678f4b51f5b08e1de42dcadf9d6187eddd	2026-03-25 05:52:20.178	2026-03-18 05:52:20.178863	\N	\N
102	7	84f5c217e8ac6d659918dd88d7a047d5c67f0e85c8c4b50c99ad3f7c1d46ec5758251ba4b8e5a623ba8f348888f35ac5	2026-03-25 06:15:52.028	2026-03-18 06:15:52.028954	\N	\N
103	1	a87d93ed37b7559c5765addb2da38b05d4aca11691e9e4a0606fd9d9a3464eb44f9b5cfe8a5657a19e2f41432e27e62f	2026-03-25 06:18:23.254	2026-03-18 06:18:23.254922	\N	\N
104	1	1d64208ff1c99d7245ea1fee2fe86b8244bc654888cb31807170267091804dc1e327a4a36a30e569d02683f6c8a39cff	2026-03-25 12:48:33.973	2026-03-18 12:48:33.974929	\N	\N
105	1	32e2c0f6bacfe721f0fde7ba37f3de525dfa24d670136c0f924614128c68f0fa1dffa09436293d4a58fabef3a8288315	2026-03-25 13:47:55.625	2026-03-18 13:47:55.626664	\N	\N
106	1	4645c6e7077b977c078433991fe813eaddac8d9018fcd5cc3030cb6bca8252292e05f458d27157931d451680fd75ca26	2026-03-25 16:37:24.886	2026-03-18 16:37:24.887851	\N	\N
107	1	b23d24e5b74e70caf7ca04c597383fcd58b197ef62bdd731bdb2988edfe116316651bc2fddf6d0ceba84d417f70fdaaf	2026-03-26 01:08:19.76	2026-03-19 01:08:19.761678	\N	\N
108	1	ba03b9cd78edb5fc8f8f6d8f82f33c74066675825ae75d8292c48e311da7edb798666995d5a4427225f0e928dfdf85d6	2026-03-26 12:42:13.654	2026-03-19 12:42:13.655926	\N	\N
109	1	f1b4ebc151dd975c5d2135260599891751497720e31afc8ab085cca6ea09914f757ff1a33c0b36597f83c31f7352e736	2026-03-26 12:42:14.364	2026-03-19 12:42:14.364741	\N	\N
110	1	3458aebd576cf543e0d93d531b3def51b27f4c9b06542acb00bbdc18b3d3bb25559bf47708e1ea5dec2e9936aa4e3311	2026-03-26 12:56:59.616	2026-03-19 12:56:59.617675	\N	\N
112	1	4011c5e0e0c65d84d2766e888fef39503e8219b69a67d6045d8e229ce13917aeddbdc02e9b8d3460c2c6580143c16738	2026-03-26 13:38:50.483	2026-03-19 13:38:50.484597	\N	\N
113	1	2ac7e9d8f842a9d31cfdb4b0a9a3443bb4ef06f46dd008acba771af290b48659628c23fb9cc702f2bf52ffb65580a3bd	2026-03-26 13:38:56.163	2026-03-19 13:38:56.163565	\N	\N
114	1	55ba64337d946420eef7af02567192d8809a9dfa633f44e3d32ad3bd86aa0613d9a199f1fd075f9541bb44c637b2d19f	2026-03-26 14:14:26.798	2026-03-19 14:14:26.799515	\N	\N
116	1	2bd46d552bd61880dbe79b401c6323cab274c337a5de7393e84d24ad2e67efae7189f569ced484634f3ade6ab9c02052	2026-03-26 15:09:44.659	2026-03-19 15:09:44.659652	\N	\N
117	1	0ce32bcdceb92888293ac84ea4ace3ac2a2ca0d1ebbb1283ec85ec3f1fd417d3bd3e6d31a6f1c0601e76061617847912	2026-03-26 17:17:42.368	2026-03-19 17:17:42.369778	\N	\N
118	1	17f871253829291f024cf46af8238727736ae714bdc4ac010256f6282278bd0d1728fe45ac403e0bc960d456a195e466	2026-03-26 17:17:42.855	2026-03-19 17:17:42.855659	\N	\N
119	2	a8a08ce42206149caf3d5968949c8267285a52cd24dbf7606ff4e7c201f92f472b6ac093ca10ed4a1896c465c4ce9762	2026-03-26 17:17:54.018	2026-03-19 17:17:54.019049	\N	\N
120	2	a87953ec60a7d4f3136f657091415db7f9869b42e68d102e1d0ed2a7ee17c0cfddd713a09d97e1b7f85d1c30f68ec472	2026-03-26 17:17:58.293	2026-03-19 17:17:58.293974	\N	\N
121	2	ecca4e21bb0c1071ef04fc60d4c66874917aca505737dc74f5cd7cfa2d285ab4969d1d4dbe7f34958c1db5617e34da14	2026-03-26 17:18:02.041	2026-03-19 17:18:02.04233	\N	\N
122	1	855870c6f7a7b1326c24d99c619e6e7a9b6b158ba40a3e1ef2d734b78bf1868b23dc24fbf46f8ff964a5853fac331a6e	2026-03-26 17:19:01.553	2026-03-19 17:19:01.55464	\N	\N
123	2	fcb6476e0730ca52d00c4d07ed066f9eb30bc2ddf31d3f076ced754d3a1648c519eca8cbc7ec3e2c18161de58c791848	2026-03-26 17:19:01.719	2026-03-19 17:19:01.719667	\N	\N
124	1	11f5702db4d66abed6a79a01850cc8961d606ec83cbbee9dcad55c1ca847fb955852840a2cae670704fd959f89902f6f	2026-03-26 17:24:52.45	2026-03-19 17:24:52.451727	\N	\N
125	1	4bfdff934c0943860ac6710edf8f3a1c60d070ee2270cd61e61c17f2de0efcaafa67a15f86d544b1ad7c90f350bb8ef5	2026-03-26 17:31:00.5	2026-03-19 17:31:00.501608	\N	\N
126	1	c4738dbd29a0902ee9b3592173626d7ade426b4c9ad03370303fecbfa50dab0cd51415d07fa5439a9c493a4b9a7ec7d0	2026-03-26 17:31:00.652	2026-03-19 17:31:00.652725	\N	\N
127	1	f8d82d8aaf3be064f29dec3983e35e4d4b429417525900415cf940a05299ef4c7db33e90156a6c07065cfe011437c2d1	2026-03-26 17:31:10.376	2026-03-19 17:31:10.376667	\N	\N
128	1	40e997e2f1ea38a9c5f8db8b3f40be02832b9fa3a48b0608f575df3e2a278d050e74b06a3455e78f8ae853dedf614a9b	2026-03-26 17:31:27.411	2026-03-19 17:31:27.412053	\N	\N
129	1	1d78258da2653ca0a7de0fc0177f770d57093d12b176204db63f9084ec5cd9588d10a426073ec1736069e8a85633d9d0	2026-03-26 17:31:46.761	2026-03-19 17:31:46.761683	\N	\N
130	1	3dadccc84cdd76c06b75ec9953cd7ed47a335336d04c04cbea9cfb91d277362070f337a03e7ea68dad96e159bedb6320	2026-03-26 17:31:47.058	2026-03-19 17:31:47.058518	\N	\N
131	1	6c26a58fc4736999b68a749f2b0305f912610aeffef579496bedd209f0e28040c670a3dba05b2c64b76ef9d01a12cdb4	2026-03-26 17:31:47.211	2026-03-19 17:31:47.211499	\N	\N
132	1	d8eca02904c5a0885df7132cd16024c70aa69d20123f25ce4d8ecff57c431c6e2a497a1f009a8e18f2fe7c830fbc6425	2026-03-26 17:35:11.168	2026-03-19 17:35:11.168882	\N	\N
133	1	628e9042af8d98bb04e99b1b4cd2300ae6e2b1f69a43c5503490e7c7241b7d05b32061880fdbde469b7a93022cde2e14	2026-03-26 17:35:11.424	2026-03-19 17:35:11.424828	\N	\N
134	1	24526753cd9684fe657ecea096710aa44207470fd25b40fc051447e48a70002d68295ec0e798a600490d8b91ce3d47fd	2026-03-19 18:38:50.599	2026-03-19 17:38:50.600329	d87d0f86237c986fcde4f4a9487c089e3a7248e3a41cd969235335975af0c4e39cb38e8abe31e06c3596c68760020b15	2026-04-18 17:38:50.599
136	1	fbede4b093a1ee2b7b2918bf7d09782108521e851a40461f1f4be899c7b03f9216bee89ce0c8b7c9805a737313bac41d	2026-03-19 18:39:02.547	2026-03-19 17:39:02.551418	9fb58c4cd55f885ec241f26cbaa842656bc1a5aafb314bf664b494818a89057bb99f08889be4b79f6f8ed6bb17ff8024	2026-04-18 17:39:02.547
137	1	9083ff3a9412f4992fa1d2da98d26d7984676c0e79f502bd04bca3fe12980ce03f7cbd7fe8118559dd388b3131126457	2026-03-19 18:40:40.86	2026-03-19 17:40:40.861505	c1203664e829bf4de176ff7a7a2d201d88d4f5aadb4bc78ac8051af54115049014b572f98ffcd8042d6d8eeabe809e9e	2026-04-18 17:40:40.86
138	1	85f67fb20b37f8776a1d4e50af9e81c4c52d04d82cc70a4685bff9ec9cee5d660c8683bfecda15223cdb815ad8bd19b6	2026-03-19 18:40:46.298	2026-03-19 17:40:46.299321	fd8cc366be3d77e59de4cf87718f62f2c803233a70439c0b9bcff73574a0309dffe425708118b9fb4efaba7c607212c0	2026-04-18 17:40:46.298
139	1	105ddad5dff663b5968019fb46dd1b86a24728c151a4d9293c9a6c8b5f105d27737f373be1ef48e5ec71fe459d99eb76	2026-03-19 18:40:52.301	2026-03-19 17:40:52.301969	c931ea3e8fb4fa3dbf4a195cc6de59efb8d96dbb52f467c3d385ddd8c220dd58e44e50f74afbdeb7a7982b912089840d	2026-04-18 17:40:52.301
140	1	f77554e8ab216c5b9e7bd178e785ec99d0612c2d23d5f698605d028292e90d723b8093b087db1d9aff3410670bab37e9	2026-03-19 18:40:58.584	2026-03-19 17:40:58.584466	ea0083246d35d84b53aa60c7b4ab6dcda276c022943bf3c1b086b94669b46db115ad175e8a59a01cc32425b58dcde768	2026-04-18 17:40:58.584
141	1	061beee703effa22f4cbf6fd3075063f86ed0d097d3eded8e043088acc22e6d581d434daefa9c8e27830353ec7e45fd4	2026-03-19 18:47:35.641	2026-03-19 17:47:35.641829	0edb298141c550bbb053151598f6d53aee1cc816f44ce27fa7910160de5c2bd18182c7fcc2071c5b0128ca7be87aeef7	2026-04-18 17:47:35.641
142	2	08226048b334898b1e3cc165c4ed0b85cc74d6c96944f930e3c5ce009729ccb3bde27315f405811175ea775cb3725a95	2026-03-19 18:47:41.169	2026-03-19 17:47:41.170106	7aa41808574b32cfb2ae76fc09527f4e6f5263e4050ba503c446686b4d9b5a942d137b37b43b80be8873c639b83f378c	2026-04-18 17:47:41.169
143	1	789d12cba56312441ea4b60344a4d33ff1942ae0c52bf05afc1ec28dfe696e5f9a4946e535162c02cb543da3e5ff609f	2026-03-19 18:50:18.008	2026-03-19 17:50:18.010246	f1ddc6bcf2270fd9ed8b51f871e4e1749862d3d8b16fbad7f5282dd1ec0c9c4e44b22b256fad99c888d247d61be0106d	2026-04-18 17:50:18.008
144	1	d90edcf6363972304a75167181312200a9ab15fa1df8889ac3e9e4ef03d11bbc5620eba852cea86bd83be461ccb3f28b	2026-03-19 18:50:24.262	2026-03-19 17:50:24.2625	e1e50e3620b63546a8302a2194fb4c271faab44c42a3b8a18b25bfc2dd9f183bee0e6cf0719d1717f6719b5b2826b310	2026-04-18 17:50:24.262
145	2	8a62caea04cbebeea24bb41acbc9479e58bfd38d190db89ef42ac01b254fbe2d2297db3c0b2df9b9d3e84eac63dd6cec	2026-03-19 18:50:30.527	2026-03-19 17:50:30.527809	c9fa7f99bb50ac37f50c910342f13500b73c529801314df511294b6d628c3e80972a26cd0d17b0ec26e83d93362292d6	2026-04-18 17:50:30.527
147	2	fd460088de44f1fdf26ad1dfea1b5511119ecca15ae55a7e79b384c2fac16b3c1412a4d7f8dc7dda5acf4f0edc0c86a7	2026-03-20 02:13:59.321	2026-03-20 01:13:59.322384	9b10e7d6eeddd5aa5382947bd6a9aec436780bd5d2c339a38fb9618e44e1cfc995b0c00fe8cf9a9a63365edd2e1547a6	2026-04-19 01:13:59.321
148	2	3081be96bb55789011973ac08696948ec555fb65eab7f2e7c666a3a8fd2a261bd9bbf1dadd44c4a25883ffa55ebd338d	2026-03-20 02:15:31.064	2026-03-20 01:15:31.064583	0e25c29f60fe3bec6e5d8a82f552a23047abb0794646f4c87632ae91ad053fe4e38597fc6b6b4969d766d22135c8fae7	2026-04-19 01:15:31.064
149	2	7b88482d5213774845a7313cf7461260f65ecf43f852536c4adc33a2827c7cccfbb8ae819f51b24ec10f6f751157c266	2026-03-20 02:15:45.818	2026-03-20 01:15:45.819109	4869d869a6e31e6c4dcc94a8b7895b396c535c5debab9a205f7fef31724c137612a6c157d73ecc0da5b847b65ae1985f	2026-04-19 01:15:45.818
150	1	32a32806a1abf04f93b894a3f5180e92682fa41df6fff3f307567c9932a72ada19fbc9beaa976997c593bd6d3ddabb81	2026-03-20 02:15:50.908	2026-03-20 01:15:50.908966	fcc264b3eb6f8f50f84ebcf27089d8205ebad8cfa0bbf7eb0a26401e9afca93e09f25660229d266d40b95e309b16e400	2026-04-19 01:15:50.908
151	1	96273d80a71107434ccb411d1c5e1a5dea116290c4ce97af844a255925f005aa3a27655a6d205e9f75e870f9d13b61f4	2026-03-20 02:16:11.65	2026-03-20 01:16:11.651165	12116edae07d187a4c497275a93c1285c6908dc9dfe5394d3d086a21709fd8e3b08e713612ebb7ac7860ed1a34b90b8e	2026-04-19 01:16:11.65
152	1	b872280cf8cb75856c3f19d6ac924f1865e432fd0b103de2e14f8aa5c849b15805560d163fb16c002ff7e0cae05b0698	2026-03-20 08:36:32.398	2026-03-20 07:36:32.399638	47e7643d5c0715148303e1aab83b322989e690f5ebcc3be6fcbe68979a05a7ec2b69502b988fc4405c8ba71ce4ee2c4f	2026-04-19 07:36:32.398
153	1	48dbd99a7cb157c8c8b3ca2c7f2f6490d8010305e7585e98e94f2221ec812604a698758dca1e8fbd20bb4b114f105796	2026-03-20 08:37:29.343	2026-03-20 07:37:29.344662	e3e98446e1d15829b1a571ffb9c50a61aee1cd02acd10e5f8a2bb94c952596b0c0cd47c4f7660c525f376c991f81bf6d	2026-04-19 07:37:29.343
154	7	8e1ef727c915e235466f7cd63d79689ad2f69ccd0cf572df63844b45338396d51bb4388260726e395e831878352e0989	2026-03-21 05:51:43.723	2026-03-21 04:51:43.72403	3f81d33b8e97319fc51278cdac461a62c664574729087f22f3213716585facb66a62bacca3089f41426d5192be2ac078	2026-04-20 04:51:43.723
156	1	598a4896ffad3efcd406949e1cf69c21892a4c5940c74715cdd8c960554176bd9a5d8ae39060b391748193f41d65dab9	2026-03-21 16:03:46.606	2026-03-21 15:03:46.606571	cb33bb5b7b01bedffd67e2266ae3561ee3a6e2daba226d163c63c635e3ea69f732b813766e97e67feb8800500dd2e455	2026-04-20 15:03:46.606
159	7	20e429963f9db217e4087bf7bb59ee8a2ad19e5b2dc0d35e74f48f5d4cc26c79d4aca7c5af539e7fc2e3e935743031ef	2026-03-21 16:15:36.797	2026-03-21 15:15:36.797371	04abf5e3517896d8c14c4b67ee9463f13055462e2a434c7b30b1077c46805f444938aa62a9b55a499d0c6f8a797a64d7	2026-04-20 15:15:36.797
160	1	066ef97fc7aee9e9f4f35bc628699dc1be93060b1d65898b739718cc1c4bf2d3708c9c1da53a551da9fbe70f39859556	2026-03-21 17:01:59.063	2026-03-21 16:01:59.064616	ea58f1c0dec8346bb64fd5c34412b8d211abe8c9a02b3dea4237a3fb917a42baf1f9d8a8858640b1f50e994e6b3a942b	2026-04-20 16:01:59.063
161	1	7c2c122a7730bd47d0936b66e429eba9cdf5fb104b637a9c3c5e7b744fd656f629d2ddc6b1d35e89e842cbd91b0eb83f	2026-03-21 17:15:26.464	2026-03-21 16:15:26.465565	605ad73a38baf314a957916de55811a01249212e4b601322b22409f3a576d547b78541e9c65769eaca4745d52d7e1586	2026-04-20 16:15:26.464
165	1	29f6b0b7dca1e0d6f21b5ca34ddc182e29a542a7577c6ecd9e351ac247a85426d762ef32414681ecaa67560d81dc7d6b	2026-03-22 12:15:09.297	2026-03-22 11:15:09.297469	c6bb434b5f72df1f651253360e4e39cbef326236b71ec4a5f33aa23ba4b78d7c6916df1500616632716e662cfff6b5a1	2026-04-21 11:15:09.297
168	7	59e9547584f065236449ed997a676f3b482b43b595af03ca9ead094768779d27d5981e76dc067ec57ba87595fea17e94	2026-03-22 13:40:23.555	2026-03-22 12:40:23.556131	7d693124980d7cbd9eba31b68ffb12b8d89c4695e32abfaaf22faf2e0f28556108bf181775ebe2afe3b7b08be9a6bff6	2026-04-21 12:40:23.555
170	7	ef211a95555a5eea52311486d0c6107fe55a6e10c1a29e28eca95466f5215dacd4525b2e9b1f1ec23d97d60755a90b39	2026-03-22 13:45:29.801	2026-03-22 12:45:29.801599	e14ff6294e1eb90693348aa8a0da3812045eb2bf8c8244272d8bd62c4a6c8d0a33ef3b760ea756a2ec0645f15ef6314b	2026-04-21 12:45:29.801
171	7	6a9bafe46cedabdb042e6f14ed3e304f15017df3b3ee49e53c6a851fa99ba101874b0737206717d115d7c1f2d43197af	2026-03-22 13:46:05.803	2026-03-22 12:46:05.80381	7eaeef39d3005678540492ac4304b2369925a94fbab54ddd866afa9a3580bd8aa0e4a0111a4cf16817ed859b798ee3b8	2026-04-21 12:46:05.803
173	7	b4e96400a4ae648cc0ddbd62bfb845490f35079c10b8a26c5225acf2f87d4781fed140f26d1433062efd7ce3584b9f8c	2026-03-22 14:53:58.38	2026-03-22 13:53:58.380426	139a9b458e45bb8c90f50640693e64b58ad5f665737989fa6a7721226bba6d89e1a3040eee0e240808ef2872dd913ac9	2026-04-21 13:53:58.38
174	1	fc0d374e2fc87a95016f1f8f25cc72add849f10251c5785cd5d14572438680a6b2c5c844cb401a166044ea9bff398695	2026-03-22 14:58:32.975	2026-03-22 13:58:32.986104	b6d5722abdba044fc113d47d647c7ed14d8045b605185c13f55cea64919e92b566683d0da365f890c4edd3a1341c2fe3	2026-04-21 13:58:32.975
175	7	5a89343fa1f5846a88d28f6ef09ce22e4beab518c58317b1ad2c2ec93b8bfbb1f8dde0fec066ab72c296d80c347e0479	2026-03-22 14:58:59.098	2026-03-22 13:58:59.09878	04010a445275b98dd270b00c4f8a6d59dcd17eb813bc624a941544a93e67f99f3fca49c78926d470bf9a0d0415f7fd6e	2026-04-21 13:58:59.098
176	1	2869110b8eee2aaf92a42cc274655b098c7cd78078c8cf98e953441d0df75229900fbf6ec264cc85cd332863d42e9aef	2026-03-22 15:01:51.058	2026-03-22 14:01:51.05924	f2d494c7a0655d85b21213b0c3001fc82da49193e55e23e80af60857c8b90e47d28a6149135fc6940ef561026deab80f	2026-04-21 14:01:51.058
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, key, value, updated_at) FROM stdin;
1	2fa_enabled	false	2026-03-19 17:31:47.252
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_comments (id, task_id, user_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: task_labels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_labels (id, task_id, label) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, status, priority, creator_id, assignee_id, conversation_id, due_date, completed_at, is_archived, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_presence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_presence (id, user_id, status, last_seen_at, updated_at) FROM stdin;
124	7	offline	2026-03-22 14:01:29.998396	2026-03-22 14:01:29.998396
1	1	offline	2026-03-22 14:18:18.976629	2026-03-22 14:18:18.976629
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, employee_id, name, email, password, phone, department, "position", avatar_url, role, is_active, created_at, updated_at, whatsapp_number, two_factor_secret, two_factor_enabled) FROM stdin;
10	EMP999	Test User	test@example.com	scrypt:1132e4b95c506fcfb826fe95252f06d34a832bc4b5f7c58dcd4185979ceca9a4:664d24b9aff647f7742d9f0b8cc62354c4f68f6454fb5da46ec19d6143eb655ee398876f615a655b70cffdc30fa693487e3cba4ee897981c6e2e189da43fed6c	\N	\N	\N	\N	employee	t	2026-03-19 17:40:52.514662	2026-03-19 17:40:52.514662	\N	\N	f
3	EMP003	Siti Rahayu	siti@corpchat.id	8edfbdb46491f2cd3b89fa8b32f1a3f0:b745edfd1186fb94bb20c3f30e54ee4bb73e07b76db8c2c292e9721c738abf004592f966402503b60f2ebb51d18ce54ece6b5eb194f01262e5cc437e915cb6d6	\N	Finance	Financial Analyst	\N	employee	t	2026-03-16 05:54:18.260715	2026-03-16 05:54:18.260715	\N	\N	f
4	EMP004	Andi Wijaya	andi@corpchat.id	e68aca608cf071eb621512c97c0d9bba:4985c5f3742609c013037a8cffed9d5e28e315da07c9e81901204c3c3a8c75f29aafc5808ba66b15d53a61917313cc83a8f3664df49b3006ee59b990c08a1dda	\N	IT	Software Developer	\N	employee	t	2026-03-16 05:54:18.260715	2026-03-16 05:54:18.260715	\N	\N	f
5	EMP005	Dewi Kusuma	dewi@corpchat.id	74c493552011c0749bb1b490c37a7e9a:4a7fa4bb946971a2202513df0949ceffdffed36dcf503344c7a07b01601d6c90bc8a5ee2e389de6e4f88535238cf398f82a6ddc585b6db0a87cf3ab819dda260	\N	Marketing	Marketing Specialist	\N	employee	t	2026-03-16 05:54:18.260715	2026-03-16 05:54:18.260715	\N	\N	f
6	EMP006	Riko Pratama	riko@corpchat.id	47e02ed5c1b766a32bd1952b32ae2339:5547564181ef2bb6077f48b3b6a3f083850b952f7a515e2733522dc445d2ef2af63f85d997b33c5dadc785cc6a49a011498654bc126794701eba19bfc0c0b517	\N	Operations	Operations Lead	\N	manager	t	2026-03-16 05:54:18.260715	2026-03-16 05:54:18.260715	\N	\N	f
1	EMP001	Admin Sistem	admin@corpchat.id	scrypt:c4415676c43da3016507e282d6e8ba05da12280e1ac94f1c276c04253a53f00b:cb9e5cb07c022ad84c2f12c129013bbdf9c05c51dbc71877ecc5ac31f7a759e02699483bc8528569a7b2fc9d27b9f0b85c27e934da174269cb146e2d5a0ef20e	\N	IT	System Administrator	\N	admin	t	2026-03-16 05:54:18.260715	2026-03-16 15:24:29.203	6281234567890	\N	f
2	EMP002	Budi Santoso	budi@corpchat.id	scrypt:88d13f685d489e0aa93fd11ba4b3dff4b5d0a1f0e927de2d9e6197b4d66ee180:43b01b66f9a0168227705b96f0e17c8db5f4e1221bc501c5c6d0b694ade24dc2497bf934c0c2bb7cce189a89e3f5e6030bad3b6117e8c29feff5868229091bf8	\N	HR	HR Manager	\N	employee	t	2026-03-16 05:54:18.260715	2026-03-16 05:54:18.260715	\N	\N	f
7	EMP007	Joni Santoso	joni@rpk.com	e2a2d9eaf9265eab56a3a9b82d4821b9:1841e15f5f6027e9b6c04d62c346b505ba0d1adf797f4492cdfc5afaf4b9e9c392fa4531533cd45b2390ecd7d8675dcfe6f5836e3727d511d7faf6c7299f4893	\N	Operations	Staff	\N	employee	t	2026-03-16 15:56:17.497683	2026-03-16 15:56:17.497683	\N	\N	f
8	EMP010	Test Import	testimport@co.id	c05c0956e189f30728f2f40cc24dfbf5:98b757471a7992aa5b6b02f0cb7475d086b93e9800a959d5cbd65352ac1a570ee91da570579f2e4b2baf519d252ef54fb61c6ed0c8e7274cd5ac501b9f5777aa	\N	HR	Staff	\N	employee	t	2026-03-16 16:05:13.770162	2026-03-16 16:05:13.770162	\N	\N	f
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcements_id_seq', 3, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attachments_id_seq', 5, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 378, true);


--
-- Name: canvas_board_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.canvas_board_members_id_seq', 1, false);


--
-- Name: canvas_boards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.canvas_boards_id_seq', 3, true);


--
-- Name: canvas_elements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.canvas_elements_id_seq', 9, true);


--
-- Name: cico_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cico_logs_id_seq', 8, true);


--
-- Name: cico_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cico_status_id_seq', 7, true);


--
-- Name: compliance_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compliance_flags_id_seq', 1, true);


--
-- Name: conversation_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversation_members_id_seq', 40, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversations_id_seq', 16, true);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_attempts_id_seq', 33, true);


--
-- Name: message_favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.message_favorites_id_seq', 1, false);


--
-- Name: message_reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.message_reactions_id_seq', 1, false);


--
-- Name: message_reads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.message_reads_id_seq', 132, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 63, true);


--
-- Name: push_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.push_tokens_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sessions_id_seq', 176, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, true);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 1, false);


--
-- Name: task_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_labels_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: user_presence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_presence_id_seq', 1014, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: canvas_board_members canvas_board_members_board_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_board_members
    ADD CONSTRAINT canvas_board_members_board_id_user_id_key UNIQUE (board_id, user_id);


--
-- Name: canvas_board_members canvas_board_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_board_members
    ADD CONSTRAINT canvas_board_members_pkey PRIMARY KEY (id);


--
-- Name: canvas_boards canvas_boards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_boards
    ADD CONSTRAINT canvas_boards_pkey PRIMARY KEY (id);


--
-- Name: canvas_elements canvas_elements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_elements
    ADD CONSTRAINT canvas_elements_pkey PRIMARY KEY (id);


--
-- Name: cico_logs cico_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cico_logs
    ADD CONSTRAINT cico_logs_pkey PRIMARY KEY (id);


--
-- Name: cico_status cico_status_employee_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cico_status
    ADD CONSTRAINT cico_status_employee_id_unique UNIQUE (employee_id);


--
-- Name: cico_status cico_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cico_status
    ADD CONSTRAINT cico_status_pkey PRIMARY KEY (id);


--
-- Name: compliance_flags compliance_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_flags
    ADD CONSTRAINT compliance_flags_pkey PRIMARY KEY (id);


--
-- Name: conversation_members conversation_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: message_favorites message_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_favorites
    ADD CONSTRAINT message_favorites_pkey PRIMARY KEY (id);


--
-- Name: message_reactions message_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_pkey PRIMARY KEY (id);


--
-- Name: message_reads message_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: offline_queue offline_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offline_queue
    ADD CONSTRAINT offline_queue_pkey PRIMARY KEY (id);


--
-- Name: push_tokens push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_token_unique UNIQUE (token);


--
-- Name: system_settings system_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_key_unique UNIQUE (key);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_labels task_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_labels
    ADD CONSTRAINT task_labels_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: user_presence user_presence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_presence
    ADD CONSTRAINT user_presence_pkey PRIMARY KEY (id);


--
-- Name: user_presence user_presence_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_presence
    ADD CONSTRAINT user_presence_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_employee_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_id_unique UNIQUE (employee_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_canvas_board_members_board; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_canvas_board_members_board ON public.canvas_board_members USING btree (board_id);


--
-- Name: idx_canvas_board_members_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_canvas_board_members_user ON public.canvas_board_members USING btree (user_id);


--
-- Name: idx_canvas_boards_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_canvas_boards_conversation ON public.canvas_boards USING btree (conversation_id);


--
-- Name: idx_canvas_boards_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_canvas_boards_created_by ON public.canvas_boards USING btree (created_by_id);


--
-- Name: idx_canvas_elements_board; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_canvas_elements_board ON public.canvas_elements USING btree (board_id);


--
-- Name: idx_compliance_flags_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compliance_flags_conversation_id ON public.compliance_flags USING btree (conversation_id);


--
-- Name: idx_compliance_flags_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compliance_flags_created_at ON public.compliance_flags USING btree (created_at);


--
-- Name: idx_compliance_flags_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compliance_flags_severity ON public.compliance_flags USING btree (severity);


--
-- Name: idx_compliance_flags_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compliance_flags_status ON public.compliance_flags USING btree (status);


--
-- Name: idx_compliance_flags_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compliance_flags_user_id ON public.compliance_flags USING btree (user_id);


--
-- Name: idx_conversation_members_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversation_members_conversation_id ON public.conversation_members USING btree (conversation_id);


--
-- Name: idx_conversation_members_conversation_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_conversation_members_conversation_user ON public.conversation_members USING btree (conversation_id, user_id);


--
-- Name: idx_conversation_members_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversation_members_user_id ON public.conversation_members USING btree (user_id);


--
-- Name: idx_conversations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversations_created_at ON public.conversations USING btree (created_at);


--
-- Name: idx_conversations_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversations_updated_at ON public.conversations USING btree (updated_at);


--
-- Name: idx_conversations_wa_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversations_wa_status ON public.conversations USING btree (wa_status);


--
-- Name: idx_message_reads_message_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_message_reads_message_id ON public.message_reads USING btree (message_id);


--
-- Name: idx_message_reads_message_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_message_reads_message_user ON public.message_reads USING btree (message_id, user_id);


--
-- Name: idx_messages_conversation_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_messages_conversation_created ON public.messages USING btree (conversation_id, created_at);


--
-- Name: idx_messages_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_messages_conversation_id ON public.messages USING btree (conversation_id);


--
-- Name: idx_messages_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_messages_created_at ON public.messages USING btree (created_at);


--
-- Name: idx_messages_sender_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_messages_sender_id ON public.messages USING btree (sender_id);


--
-- Name: idx_offline_queue_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_offline_queue_status ON public.offline_queue USING btree (status);


--
-- Name: idx_offline_queue_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_offline_queue_user ON public.offline_queue USING btree (user_id);


--
-- Name: idx_push_tokens_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_push_tokens_token ON public.push_tokens USING btree (token);


--
-- Name: idx_push_tokens_user_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_push_tokens_user_token ON public.push_tokens USING btree (user_id, token);


--
-- Name: idx_task_comments_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_comments_task_id ON public.task_comments USING btree (task_id);


--
-- Name: idx_task_labels_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_labels_task_id ON public.task_labels USING btree (task_id);


--
-- Name: idx_tasks_assignee_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_assignee_id ON public.tasks USING btree (assignee_id);


--
-- Name: idx_tasks_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_conversation_id ON public.tasks USING btree (conversation_id);


--
-- Name: idx_tasks_creator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_creator_id ON public.tasks USING btree (creator_id);


--
-- Name: idx_tasks_due_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_due_date ON public.tasks USING btree (due_date);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- Name: login_attempts_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX login_attempts_created_at_idx ON public.login_attempts USING btree (created_at);


--
-- Name: login_attempts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX login_attempts_user_id_idx ON public.login_attempts USING btree (user_id);


--
-- Name: sessions_refresh_token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sessions_refresh_token_unique ON public.sessions USING btree (refresh_token) WHERE (refresh_token IS NOT NULL);


--
-- Name: announcements announcements_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: attachments attachments_message_id_messages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_message_id_messages_id_fk FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: canvas_board_members canvas_board_members_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_board_members
    ADD CONSTRAINT canvas_board_members_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.canvas_boards(id) ON DELETE CASCADE;


--
-- Name: canvas_board_members canvas_board_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_board_members
    ADD CONSTRAINT canvas_board_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: canvas_boards canvas_boards_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_boards
    ADD CONSTRAINT canvas_boards_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: canvas_boards canvas_boards_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_boards
    ADD CONSTRAINT canvas_boards_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: canvas_elements canvas_elements_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_elements
    ADD CONSTRAINT canvas_elements_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.canvas_boards(id) ON DELETE CASCADE;


--
-- Name: canvas_elements canvas_elements_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canvas_elements
    ADD CONSTRAINT canvas_elements_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: compliance_flags compliance_flags_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_flags
    ADD CONSTRAINT compliance_flags_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: compliance_flags compliance_flags_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_flags
    ADD CONSTRAINT compliance_flags_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: compliance_flags compliance_flags_reviewed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_flags
    ADD CONSTRAINT compliance_flags_reviewed_by_id_fkey FOREIGN KEY (reviewed_by_id) REFERENCES public.users(id);


--
-- Name: compliance_flags compliance_flags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_flags
    ADD CONSTRAINT compliance_flags_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: conversation_members conversation_members_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: conversation_members conversation_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: conversations conversations_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id);


--
-- Name: conversations conversations_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: login_attempts login_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_reactions message_reactions_message_id_messages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_message_id_messages_id_fk FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: message_reactions message_reactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: message_reads message_reads_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_reads message_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: messages messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: offline_queue offline_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offline_queue
    ADD CONSTRAINT offline_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: push_tokens push_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_labels task_labels_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_labels
    ADD CONSTRAINT task_labels_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: tasks tasks_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: user_presence user_presence_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_presence
    ADD CONSTRAINT user_presence_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Nanbqbq2aDMTVfwQbCmdMSKiSpLsG3Sk9kw0pZOY46f6c8edE2FW87x9Vwvpbby

